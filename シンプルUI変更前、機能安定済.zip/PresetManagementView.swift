// MARK: - 役割: レンズ・フィルムのプリセット管理画面

import SwiftUI

struct PresetManagementView: View {
    enum Mode {
        case onboarding
        case manage

        var title: String {
            switch self {
            case .onboarding: return "ボディ・フィルム登録"
            case .manage: return "プリセット管理"
            }
        }

        var description: String {
            switch self {
            case .onboarding:
                return "使用された「カメラ」「レンズ」「フィルム」の情報を元にスキャナーを調整することで、色の再現度や解像感が劇的に向上します。最高の結果をお求めの方は、可能な範囲でご記入をお願いいたします。"
            case .manage:
                return "新規登録または変更があれば更新してください。"
            }
        }
    }

    @ObservedObject var sessionStore: AppSessionStore
    let mode: Mode
    var refined: Bool = true
    @Binding var suppressPrompt: Bool
    var onDismiss: (() -> Void)?

    @Environment(\.dismiss) private var dismiss

    @State private var editingPresetID: UUID?
    @State private var cameraBody: String = ""
    @State private var lensDetails: String = ""
    @State private var isZoomLens: Bool = false
    @State private var primeFocalLengthText: String = ""
    @State private var film: String = ""
    @State private var date: Date = Date()
    @State private var copiedPresetID: UUID?

    private var backgroundColor: Color { refined ? .refinedBackground : .meterBackground }
    private var surfaceColor: Color { refined ? .refinedSurface : .meterCardBg }
    private var onboardingContainerColor: Color {
        refined ? .refinedPanelSoft : Color(red: 0.80, green: 0.78, blue: 0.75)
    }
    private var panelColor: Color { refined ? .refinedPanel : .meterAccent }
    private var primaryTextColor: Color { refined ? .refinedText : .meterSecondary }
    private var secondaryTextColor: Color { refined ? .refinedTextSoft : .meterSecondary.opacity(0.72) }
    private var strokeColor: Color { refined ? .refinedStroke : Color.black.opacity(0.12) }
    private var onboardingOutlineColor: Color {
        refined ? Color.white.opacity(0.16) : Color.black.opacity(0.16)
    }
    private var onboardingAccentStrokeColor: Color {
        refined ? .cyan.opacity(0.24) : .meterAccent.opacity(0.18)
    }
    private var onboardingGlowColor: Color {
        refined ? .cyan.opacity(0.12) : .meterAccent.opacity(0.10)
    }
    private var buttonTextColor: Color { refined ? .refinedTextOnDark : .black }
    private var toggleTintColor: Color { refined ? .cyan : .meterAccent }
    private var toggleRowBackgroundColor: Color {
        refined ? .refinedSurface.opacity(0.96) : Color.white.opacity(0.42)
    }
    private var toggleRowStrokeColor: Color {
        refined ? Color.white.opacity(0.14) : Color.black.opacity(0.12)
    }
    private var pickerTintColor: Color { refined ? .refinedText : .meterSecondary }
    private var activeIndicatorColor: Color { refined ? .refinedText : .meterSecondary }
    private var chipForegroundColor: Color { refined ? .refinedText : .meterSecondary }
    private var copiedChipBorderColor: Color { refined ? Color.white.opacity(0.2) : Color.black.opacity(0.08) }

    var body: some View {
        Group {
            if mode == .onboarding {
                onboardingBody
            } else {
                manageBody
            }
        }
        .preferredColorScheme(refined ? .dark : .light)
    }

    private var onboardingBody: some View {
        ZStack(alignment: .topLeading) {
            onboardingContainerColor

            VStack(spacing: 0) {
                onboardingHeader

                Divider()
                    .background(strokeColor)

                VStack(alignment: .leading, spacing: 16) {
                    contentStack
                    suppressPromptToggle
                }
                .padding(20)
            }
            .frame(maxWidth: .infinity, alignment: .top)
            
            Circle()
                .fill(onboardingGlowColor)
                .frame(width: 220, height: 220)
                .blur(radius: 24)
                .offset(x: -36, y: -70)
                .allowsHitTesting(false)
        }
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(onboardingOutlineColor, lineWidth: 1)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(onboardingAccentStrokeColor, lineWidth: 0.6)
                .padding(1)
        )
    }

    private var manageBody: some View {
        NavigationStack {
            ZStack {
                backgroundColor.ignoresSafeArea()

                GeometryReader { geometry in
                    ScrollView {
                        contentStack
                            .padding()
                            .frame(width: geometry.size.width)
                    }
                }
            }
            .navigationTitle(mode.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("完了") {
                        handleDismiss()
                    }
                    .foregroundColor(primaryTextColor)
                }
            }
        }
    }

    private var onboardingHeader: some View {
        HStack(alignment: .center, spacing: 16) {
            Text(mode.title)
                .font(.system(size: 26, weight: .bold))
                .foregroundColor(primaryTextColor)
                .lineLimit(1)
                .minimumScaleFactor(0.8)

            Spacer(minLength: 12)

            Button("完了") {
                handleDismiss()
            }
            .font(.meterValue(14))
            .foregroundColor(buttonTextColor)
            .padding(.horizontal, 18)
            .padding(.vertical, 10)
            .background(
                Capsule()
                    .fill(panelColor)
                    .overlay(
                        Capsule()
                            .stroke(strokeColor, lineWidth: 1)
                    )
            )
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 18)
    }

    private var contentStack: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(mode.description)
                .font(.meterLabel(12))
                .foregroundColor(secondaryTextColor)

            formCard
            presetListCard
        }
    }

    private var formCard: some View {
        VStack(spacing: 10) {
            TextField("カメラボディ", text: $cameraBody)
                .textInputAutocapitalization(.words)
                .textFieldStyle(.roundedBorder)

            TextField("レンズ詳細（メーカー・型番など）", text: $lensDetails)
                .textInputAutocapitalization(.words)
                .textFieldStyle(.roundedBorder)

            Toggle(isOn: $isZoomLens) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("ズームレンズ")
                        .font(.meterLabel(12))
                        .foregroundColor(primaryTextColor)
                    Text("オンでプレビュー画角を全画面ピンチズーム、オフで単焦点画角（35mm）に変更")
                        .font(.meterLabel(10))
                        .foregroundColor(secondaryTextColor)
                }
            }
            .toggleStyle(.switch)
            .tint(toggleTintColor)

            TextField("フィルム", text: $film)
                .textInputAutocapitalization(.words)
                .textFieldStyle(.roundedBorder)

            if !isZoomLens {
                HStack {
                    TextField("焦点距離（35mm換算）例: 50", text: $primeFocalLengthText)
                        .keyboardType(.numberPad)
                        .textFieldStyle(.roundedBorder)
                        .frame(width: 180)
                    Spacer(minLength: 0)
                }

                Text("単焦点レンズのときだけ入力してください。ここで設定した値をプレビュー画角の固定に使います。")
                    .font(.meterLabel(10))
                    .foregroundColor(secondaryTextColor)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }

            DatePicker("日付", selection: $date, displayedComponents: .date)
                .datePickerStyle(.compact)
                .environment(\.locale, Locale(identifier: "ja_JP"))
                .font(.meterLabel(13))
                .foregroundColor(primaryTextColor)
                .tint(pickerTintColor)

            Button {
                sessionStore.upsertPreset(
                    editingID: editingPresetID,
                    cameraBody: cameraBody,
                    lens: lensDetails,
                    lensType: isZoomLens ? .zoom : .prime,
                    primeFocalLength35mm: parsedPrimeFocalLength,
                    film: film,
                    date: date
                )
                clearForm()
            } label: {
                Text(editingPresetID == nil ? "プリセットを追加" : "プリセットを更新")
                    .font(.meterValue(13))
                    .foregroundColor(buttonTextColor)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(RoundedRectangle(cornerRadius: 8).fill(panelColor))
            }

            if editingPresetID != nil {
                Button("編集をキャンセル") {
                    clearForm()
                }
                .font(.meterLabel(12))
                .foregroundColor(secondaryTextColor)
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(surfaceColor)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(strokeColor, lineWidth: 0.5))
        )
    }

    private var presetListCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            if sessionStore.presets.isEmpty {
                Text("まだプリセットがありません")
                    .font(.meterLabel(12))
                    .foregroundColor(secondaryTextColor)
            } else {
                ForEach(Array(sessionStore.presets.enumerated()), id: \.element.id) { index, preset in
                    let isActive = sessionStore.selectedPresetID == preset.id
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(alignment: .top) {
                            HStack(alignment: .top, spacing: 8) {
                                Circle()
                                    .fill(isActive ? activeIndicatorColor : Color.clear)
                                    .frame(width: 8, height: 8)
                                    .padding(.top, 5)

                                VStack(alignment: .leading, spacing: 4) {
                                    presetTextBlock(
                                        for: preset,
                                        index: index + 1,
                                        textSize: 13,
                                        numberSize: 18
                                    )
                                    Text(preset.formattedDate)
                                        .font(.meterLabel(11))
                                        .foregroundColor(secondaryTextColor)
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)

                            Button {
                                preset.copyToClipboard(index: index + 1)
                                withAnimation { copiedPresetID = preset.id }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    withAnimation { if copiedPresetID == preset.id { copiedPresetID = nil } }
                                }
                            } label: {
                                let isCopied = copiedPresetID == preset.id
                                presetActionChip(
                                    title: isCopied ? "コピー済み" : "コピー",
                                    systemImage: isCopied ? "checkmark" : "doc.on.doc",
                                    foregroundColor: chipForegroundColor,
                                    backgroundColor: isCopied ? Color.meterGreen : Color.clear,
                                    borderColor: isCopied ? copiedChipBorderColor : strokeColor,
                                    borderLineWidth: isCopied ? 0 : 1
                                )
                            }
                        }

                        HStack {
                            Button {
                                sessionStore.selectPreset(id: preset.id)
                            } label: {
                                presetActionChip(
                                    title: isActive ? "選択済み" : "使用する",
                                    systemImage: isActive ? "checkmark.circle.fill" : "checkmark.circle",
                                    foregroundColor: chipForegroundColor,
                                    backgroundColor: isActive ? panelColor : Color.clear,
                                    borderColor: strokeColor,
                                    borderLineWidth: isActive ? 0 : 1
                                )
                            }
                            .disabled(isActive)

                            Spacer()

                            Button("編集") {
                                editingPresetID = preset.id
                                cameraBody = preset.cameraBody
                                lensDetails = preset.lensDetailsText
                                isZoomLens = preset.lensType == .zoom
                                primeFocalLengthText = preset.primeFocalLength35mm.map(String.init) ?? ""
                                film = preset.film
                                date = preset.date
                            }
                            .font(.meterLabel(11))
                            .foregroundColor(secondaryTextColor)

                            Button("削除", role: .destructive) {
                                sessionStore.deletePreset(id: preset.id)
                            }
                            .font(.meterLabel(11))
                        }
                    }
                    .padding(.vertical, 4)

                    if index != sessionStore.presets.count - 1 {
                        Divider().background(strokeColor)
                    }
                }
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(surfaceColor)
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(strokeColor, lineWidth: 0.5))
        )
    }

    private var suppressPromptToggle: some View {
        Toggle(isOn: $suppressPrompt) {
            Text("しばらく表示しない")
                .font(.meterLabel(11))
                .foregroundColor(primaryTextColor)
        }
        .toggleStyle(.switch)
        .tint(toggleTintColor)
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(toggleRowBackgroundColor)
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(toggleRowStrokeColor, lineWidth: 0.8)
                )
        )
    }

    private func presetActionChip(
        title: String,
        systemImage: String,
        foregroundColor: Color,
        backgroundColor: Color,
        borderColor: Color,
        borderLineWidth: CGFloat
    ) -> some View {
        Label(title, systemImage: systemImage)
            .font(.meterLabel(11))
            .foregroundColor(foregroundColor)
            .frame(width: 108)
            .padding(.vertical, 6)
            .background(
                RoundedRectangle(cornerRadius: 7)
                    .fill(backgroundColor)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 7)
                    .stroke(borderColor, lineWidth: borderLineWidth)
            )
            .contentShape(RoundedRectangle(cornerRadius: 7))
    }

    private func presetTextBlock(
        for preset: CameraFilmPreset,
        index: Int,
        textSize: CGFloat,
        numberSize: CGFloat
    ) -> some View {
        let lines = preset.displayLines
        let symbol = preset.displayIndexSymbol(index: index)
        let numberColumnWidth = numberSize + 4

        return VStack(alignment: .leading, spacing: 2) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text(symbol)
                    .font(.system(size: numberSize, weight: .semibold, design: .rounded))
                    .foregroundColor(primaryTextColor)
                    .frame(width: numberColumnWidth, alignment: .leading)

                Text(lines[0])
                    .font(.system(size: textSize, weight: .medium, design: .monospaced))
                    .foregroundColor(primaryTextColor)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }

            ForEach(Array(lines.dropFirst().enumerated()), id: \.offset) { _, line in
                Text(line)
                    .font(.system(size: textSize, weight: .medium, design: .monospaced))
                    .foregroundColor(primaryTextColor)
                    .padding(.leading, numberColumnWidth + 8)
                    .lineLimit(1)
                    .minimumScaleFactor(0.7)
            }
        }
    }

    private func clearForm() {
        editingPresetID = nil
        cameraBody = ""
        lensDetails = ""
        isZoomLens = false
        primeFocalLengthText = ""
        film = ""
        date = Date()
    }

    private var parsedPrimeFocalLength: Int? {
        let trimmed = primeFocalLengthText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        return Int(trimmed)
    }

    private func handleDismiss() {
        if mode == .onboarding {
            sessionStore.dismissPresetPrompt(suppress: suppressPrompt)
        }

        if let onDismiss {
            onDismiss()
        } else {
            dismiss()
        }
    }
}
