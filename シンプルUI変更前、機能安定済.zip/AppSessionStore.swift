// MARK: - 役割: アプリ全体の設定・プリセット・起動状態を保持するセッションストア

import Foundation
import Combine
import UIKit

enum PresetLensType: String, Codable, CaseIterable, Identifiable {
    case prime
    case zoom

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .prime: return "単焦点"
        case .zoom: return "ズーム"
        }
    }
}

struct CameraFilmPreset: Identifiable, Codable, Equatable {
    var id: UUID
    var cameraBody: String
    var lens: String
    var lensType: PresetLensType
    var primeFocalLength35mm: Int?
    var film: String
    var date: Date

    init(
        id: UUID = UUID(),
        cameraBody: String,
        lens: String = "",
        lensType: PresetLensType = .prime,
        primeFocalLength35mm: Int? = nil,
        film: String,
        date: Date = Date()
    ) {
        self.id = id
        self.cameraBody = cameraBody
        self.lensType = lensType
        self.primeFocalLength35mm = lensType == .prime ? primeFocalLength35mm : nil
        self.lens = CameraFilmPreset.normalizedLensDetails(
            rawLens: lens,
            lensType: lensType,
            primeFocalLength35mm: self.primeFocalLength35mm
        )
        self.film = film
        self.date = date
    }

    private enum CodingKeys: String, CodingKey {
        case id
        case cameraBody
        case lens
        case lensType
        case primeFocalLength35mm
        case film
        case date
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        id = try container.decode(UUID.self, forKey: .id)
        cameraBody = try container.decode(String.self, forKey: .cameraBody)
        film = try container.decode(String.self, forKey: .film)
        date = try container.decode(Date.self, forKey: .date)

        let rawLens = try container.decodeIfPresent(String.self, forKey: .lens) ?? ""
        let decodedLensType = try container.decodeIfPresent(PresetLensType.self, forKey: .lensType)
        let decodedPrimeFocalLength = try container.decodeIfPresent(Int.self, forKey: .primeFocalLength35mm)

        let inferredLensType = decodedLensType ?? Self.inferredLensType(from: rawLens, primeFocalLength35mm: decodedPrimeFocalLength)
        let inferredPrimeFocalLength = inferredLensType == .prime
            ? (decodedPrimeFocalLength ?? Self.inferredPrimeFocalLength35mm(from: rawLens))
            : nil

        lensType = inferredLensType
        primeFocalLength35mm = inferredPrimeFocalLength
        lens = Self.normalizedLensDetails(rawLens: rawLens, lensType: inferredLensType, primeFocalLength35mm: inferredPrimeFocalLength)
    }

    private static let dateFormatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy/MM/dd"
        return f
    }()

    var formattedDate: String {
        Self.dateFormatter.string(from: date)
    }

    var lensDisplayText: String {
        switch lensType {
        case .prime:
            if let primeFocalLength35mm {
                return "\(primeFocalLength35mm)mm"
            }
            return "単焦点"
        case .zoom:
            return "ズーム"
        }
    }

    var lensDetailsText: String {
        lens.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var preferredEquivalentFocalLength: Double {
        switch lensType {
        case .prime:
            return Double(primeFocalLength35mm ?? 35)
        case .zoom:
            return 35
        }
    }

    var allowsInteractiveZoom: Bool {
        lensType == .zoom
    }

    var displayLines: [String] {
        let lines: [String] = [
            cameraBody.isEmpty ? nil : "カメラ：\(cameraBody)",
            lensDetailsText.isEmpty ? nil : "レンズ：\(lensDetailsText)",
            film.isEmpty ? nil : "フィルム：\(film)"
        ].compactMap { $0 }

        return lines.isEmpty ? ["未入力"] : lines
    }

    func displayIndexSymbol(index: Int) -> String {
        index.circledNumber
    }

    func formattedText(index: Int) -> String {
        let lines = displayLines
        let firstLine = "\(displayIndexSymbol(index: index)) \(lines[0])"
        let remainingLines = lines.dropFirst().map { "　 \($0)" }
        return ([firstLine] + remainingLines).joined(separator: "\n")
    }

    func copyToClipboard(index: Int) {
        UIPasteboard.general.string = formattedText(index: index)
    }

    private static func normalizedLensDetails(rawLens: String, lensType: PresetLensType, primeFocalLength35mm: Int?) -> String {
        let trimmedLens = rawLens.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedLens.isEmpty else { return "" }

        switch lensType {
        case .prime:
            if let primeFocalLength35mm, trimmedLens == "\(primeFocalLength35mm)mm" {
                return ""
            }
        case .zoom:
            let normalized = trimmedLens.lowercased()
            if normalized == "zoom" || normalized == "ズーム" {
                return ""
            }
        }

        return trimmedLens
    }

    private static func inferredLensType(from rawLens: String, primeFocalLength35mm: Int?) -> PresetLensType {
        if primeFocalLength35mm != nil {
            return .prime
        }

        let normalized = rawLens.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if normalized.contains("zoom") || normalized.contains("ズーム") {
            return .zoom
        }
        return .prime
    }

    private static func inferredPrimeFocalLength35mm(from rawLens: String) -> Int? {
        let normalized = rawLens.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard normalized.hasSuffix("mm") else { return nil }

        let numberPart = normalized.dropLast(2)
        guard !numberPart.isEmpty, numberPart.allSatisfy(\.isNumber) else { return nil }
        return Int(numberPart)
    }
}

private struct StoredSessionState: Codable {
    var hasCompletedPresetOnboarding: Bool
    var presets: [CameraFilmPreset]
    var selectedPresetID: UUID?
    var totalLaunchCount: Int?
    var presetPromptDismissedAtLaunchCount: Int?

    static let initial = StoredSessionState(
        hasCompletedPresetOnboarding: false,
        presets: [],
        selectedPresetID: nil,
        totalLaunchCount: 0,
        presetPromptDismissedAtLaunchCount: 0
    )
}

@MainActor
final class AppSessionStore: ObservableObject {
    @Published private(set) var hasCompletedPresetOnboarding: Bool = false
    @Published private(set) var presets: [CameraFilmPreset] = []
    @Published private(set) var selectedPresetID: UUID?
    @Published private(set) var totalLaunchCount: Int = 0
    @Published private(set) var presetPromptDismissedAtLaunchCount: Int = 0

    let orderPageURL = URL(string: "https://filmshop.natsusomare.jp/collections/%E7%8F%BE%E5%83%8F%E3%83%87%E3%83%BC%E3%82%BF%E5%8C%96")

    private let defaults = UserDefaults.standard
    private let stateKey = "appSessionState.v1"
    private var hasCountedThisSession = false

    init() {
        load()
    }

    var shouldShowPresetPrompt: Bool {
        guard activePreset == nil else { return false }
        if presetPromptDismissedAtLaunchCount > 0 {
            return (totalLaunchCount - presetPromptDismissedAtLaunchCount) > 5
        }
        return true
    }

    var activePreset: CameraFilmPreset? {
        guard let selectedPresetID else { return nil }
        return presets.first { $0.id == selectedPresetID }
    }

    func dismissPresetPrompt(suppress: Bool) {
        if suppress {
            presetPromptDismissedAtLaunchCount = totalLaunchCount
        }
        save()
    }

    func incrementLaunchCountIfNeeded() {
        guard !hasCountedThisSession else { return }
        hasCountedThisSession = true
        totalLaunchCount += 1
        save()
    }

    func upsertPreset(
        editingID: UUID?,
        cameraBody: String,
        lens: String,
        lensType: PresetLensType,
        primeFocalLength35mm: Int?,
        film: String,
        date: Date
    ) {
        let normalizedCamera = cameraBody.trimmingCharacters(in: .whitespacesAndNewlines)
        let normalizedLens = lens.trimmingCharacters(in: .whitespacesAndNewlines)
        let normalizedFilm = film.trimmingCharacters(in: .whitespacesAndNewlines)
        let normalizedPrimeFocalLength = lensType == .prime ? primeFocalLength35mm : nil
        let hasLensInfo = lensType == .zoom || normalizedPrimeFocalLength != nil || !normalizedLens.isEmpty

        // 一部空欄は許可。全項目空欄のみ保存しない。
        guard !normalizedCamera.isEmpty || hasLensInfo || !normalizedFilm.isEmpty else { return }

        if let editingID, let index = presets.firstIndex(where: { $0.id == editingID }) {
            var updated = presets
            updated[index].cameraBody = normalizedCamera
            updated[index].lensType = lensType
            updated[index].primeFocalLength35mm = normalizedPrimeFocalLength
            updated[index].lens = CameraFilmPreset(
                id: updated[index].id,
                cameraBody: normalizedCamera,
                lens: normalizedLens,
                lensType: lensType,
                primeFocalLength35mm: normalizedPrimeFocalLength,
                film: normalizedFilm,
                date: date
            ).lens
            updated[index].film = normalizedFilm
            updated[index].date = date
            presets = updated
            selectedPresetID = updated[index].id
        } else {
            let newPreset = CameraFilmPreset(
                cameraBody: normalizedCamera,
                lens: normalizedLens,
                lensType: lensType,
                primeFocalLength35mm: normalizedPrimeFocalLength,
                film: normalizedFilm,
                date: date
            )
            presets.append(newPreset)
            selectedPresetID = newPreset.id
        }

        hasCompletedPresetOnboarding = true
        presetPromptDismissedAtLaunchCount = 0
        save()
    }

    func selectPreset(id: UUID?) {
        selectedPresetID = id
        if id != nil {
            presetPromptDismissedAtLaunchCount = 0
        }
        save()
    }

    func deletePreset(id: UUID) {
        presets.removeAll { $0.id == id }
        if selectedPresetID == id {
            selectedPresetID = nil
        }
        save()
    }

    private func load() {
        guard let data = defaults.data(forKey: stateKey),
              let decoded = try? JSONDecoder().decode(StoredSessionState.self, from: data) else {
            apply(StoredSessionState.initial)
            return
        }

        apply(decoded)
    }

    private func apply(_ state: StoredSessionState) {
        hasCompletedPresetOnboarding = state.hasCompletedPresetOnboarding
        presets = state.presets
        selectedPresetID = state.selectedPresetID.flatMap { presetID in
            presets.contains(where: { $0.id == presetID }) ? presetID : nil
        }
        totalLaunchCount = state.totalLaunchCount ?? 0
        presetPromptDismissedAtLaunchCount = state.presetPromptDismissedAtLaunchCount ?? 0
    }

    private func save() {
        let state = StoredSessionState(
            hasCompletedPresetOnboarding: hasCompletedPresetOnboarding,
            presets: presets,
            selectedPresetID: selectedPresetID,
            totalLaunchCount: totalLaunchCount,
            presetPromptDismissedAtLaunchCount: presetPromptDismissedAtLaunchCount
        )

        if let data = try? JSONEncoder().encode(state) {
            defaults.set(data, forKey: stateKey)
        }
    }
}

private extension Int {
    var circledNumber: String {
        let map: [Int: String] = [
            1: "①", 2: "②", 3: "③", 4: "④", 5: "⑤",
            6: "⑥", 7: "⑦", 8: "⑧", 9: "⑨", 10: "⑩",
            11: "⑪", 12: "⑫", 13: "⑬", 14: "⑭", 15: "⑮",
            16: "⑯", 17: "⑰", 18: "⑱", 19: "⑲", 20: "⑳"
        ]
        return map[self] ?? "\(self)."
    }
}
