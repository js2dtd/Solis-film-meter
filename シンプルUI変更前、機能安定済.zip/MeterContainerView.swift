// MARK: - 役割: 通常画面と全画面を束ねるメインコンテナ

import SwiftUI

enum SharedPreviewSurfaceID: Hashable {
    case panel
    case fullscreen
}

struct SharedPreviewSurfacePreferenceKey: PreferenceKey {
    static var defaultValue: [SharedPreviewSurfaceID: CGRect] = [:]

    static func reduce(value: inout [SharedPreviewSurfaceID: CGRect], nextValue: () -> [SharedPreviewSurfaceID: CGRect]) {
        value.merge(nextValue(), uniquingKeysWith: { _, new in new })
    }
}

struct SharedPreviewSurfaceReporter: View {
    let id: SharedPreviewSurfaceID

    var body: some View {
        GeometryReader { proxy in
            Color.clear
                .preference(
                    key: SharedPreviewSurfacePreferenceKey.self,
                    value: [id: proxy.frame(in: .named("meterContainer"))]
                )
        }
    }
}

struct MeterContainerView: View {
    @Environment(\.scenePhase) private var scenePhase
    @ObservedObject var sessionStore: AppSessionStore

    @StateObject private var viewModel = ExposureViewModel()
    @StateObject private var cameraManager = LightMeterCameraManager()
    @StateObject private var shotRecordStore = ShotRecordStore()

    @State private var controlPanelOffset: CGFloat = 400
    @State private var showSettings = false
    @State private var showShotHistory = false
    @State private var showPresetManager = false
    @State private var showInitialDisplayGuide = UserDefaults.standard.savedSettings?.hasSeenDisplayModeGuide != true
    @State private var suppressPresetPrompt = false
    @State private var lastReflectiveMeteringMode: MeteringMode = .centerWeighted
    @State private var containerSize: CGSize = .zero
    @State private var sharedPreviewFrames: [SharedPreviewSurfaceID: CGRect] = [:]
    @State private var hasStartedMeterFlow = false

    private var isControlPanelOpen: Bool { controlPanelOffset < 1 }
    private var screenWidth: CGFloat { containerSize.width > 0 ? containerSize.width : 400 }
    private var screenHeight: CGFloat { containerSize.height > 0 ? containerSize.height : 800 }
    private var shouldPromptPresetSelection: Bool { sessionStore.shouldShowPresetPrompt }
    private var transitionProgress: CGFloat {
        let width = max(screenWidth, 1)
        return min(max(controlPanelOffset / width, 0), 1)
    }
    private var panelPreviewFrame: CGRect {
        sharedPreviewFrames[.panel] ?? .zero
    }
    private var fullscreenPreviewFrame: CGRect {
        sharedPreviewFrames[.fullscreen] ?? .zero
    }
    private var effectivePanelPreviewFrame: CGRect {
        guard panelPreviewFrame.width > 1, panelPreviewFrame.height > 1 else {
            let fallbackWidth: CGFloat = 187
            let fallbackHeight: CGFloat = 280
            return CGRect(
                x: max(0, (screenWidth - fallbackWidth) / 2),
                y: max(0, (screenHeight - fallbackHeight) * 0.18),
                width: fallbackWidth,
                height: fallbackHeight
            )
        }
        return panelPreviewFrame
    }
    private var effectiveFullscreenPreviewFrame: CGRect {
        guard fullscreenPreviewFrame.width > 1, fullscreenPreviewFrame.height > 1 else {
            return CGRect(origin: .zero, size: containerSize)
        }
        return fullscreenPreviewFrame
    }
    private var interpolatedPreviewFrame: CGRect {
        let start = effectivePanelPreviewFrame
        let end = effectiveFullscreenPreviewFrame
        let progress = transitionProgress

        return CGRect(
            x: start.minX + ((end.minX - start.minX) * progress),
            y: start.minY + ((end.minY - start.minY) * progress),
            width: start.width + ((end.width - start.width) * progress),
            height: start.height + ((end.height - start.height) * progress)
        )
    }
    private var activePreviewVisibleRect: CGRect {
        let frame = interpolatedPreviewFrame
        guard frame.width > 1, frame.height > 1 else { return .zero }

        let targetFrame: CGRect = transitionProgress > 0.99 ? effectiveFullscreenPreviewFrame : frame
        let localRect = targetFrame.offsetBy(dx: -frame.minX, dy: -frame.minY)
        let bounds = CGRect(origin: .zero, size: frame.size)
        let clippedRect = localRect.intersection(bounds)
        return clippedRect.isNull ? bounds : clippedRect
    }
    var body: some View {
        ZStack {
            (viewModel.showAuxiliaryLabels ? Color.meterBackground : Color.refinedBackground)
                .ignoresSafeArea()

            GeometryReader { geo in
                Color.clear.onAppear {
                    containerSize = geo.size
                    controlPanelOffset = geo.size.width
                }
                .onChange(of: geo.size) { _, newSize in
                    containerSize = newSize
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            sharedPreviewOverlay

            FullScreenMeterView(
                cameraManager: cameraManager,
                viewModel: viewModel,
                shotRecordStore: shotRecordStore,
                controlPanelOffset: $controlPanelOffset,
                screenWidth: screenWidth,
                showSettings: $showSettings,
                showShotHistory: $showShotHistory
            )
            .opacity(viewModel.isIncidentMode ? 1 : Double(transitionProgress))
            .allowsHitTesting(viewModel.isIncidentMode || transitionProgress > 0.5)

            ContentView(
                viewModel: viewModel,
                cameraManager: cameraManager,
                shotRecordStore: shotRecordStore,
                controlPanelOffset: $controlPanelOffset,
                screenWidth: screenWidth,
                showSettings: $showSettings,
                showShotHistory: $showShotHistory,
                showPresetManager: $showPresetManager
            )
            .opacity(viewModel.isIncidentMode ? 0 : Double(1 - transitionProgress))
            .allowsHitTesting(!viewModel.isIncidentMode && transitionProgress <= 0.5)
            .zIndex(1)

            if showPresetManager {
                presetOverlay
                    .transition(.opacity)
                    .zIndex(2)
            }
        }
        .coordinateSpace(name: "meterContainer")
        .onPreferenceChange(SharedPreviewSurfacePreferenceKey.self) { sharedPreviewFrames = $0 }
        .statusBarHidden(!isControlPanelOpen)
        .onAppear {
            if !showInitialDisplayGuide {
                startMeterFlowIfNeeded()
            }
        }
        .onDisappear {
            cameraManager.stopSession()
            hasStartedMeterFlow = false
        }
        .onChange(of: cameraManager.currentEV) { _, newValue in
            let shouldForceUpdate = viewModel.meteringMode == .threePoint && cameraManager.threePointMetering != nil
            viewModel.updateMeasuredEV(newValue, force: shouldForceUpdate)
        }
        .onChange(of: viewModel.meteringMode) { _, newValue in
            if !viewModel.isIncidentMode && viewModel.isLocked {
                viewModel.setLock(false)
                cameraManager.unlockExposure()
            }
            cameraManager.setMeteringMode(newValue)
        }
        .onChange(of: viewModel.exposureMode) { _, _ in
            guard !viewModel.isIncidentMode, viewModel.meteringMode == .threePoint else { return }
            if viewModel.isLocked {
                viewModel.setLock(false)
                cameraManager.unlockExposure()
            }
            cameraManager.restartThreePointSelection()
        }
        .onChange(of: viewModel.isIncidentMode) { _, newValue in
            if newValue {
                lastReflectiveMeteringMode = viewModel.meteringMode
                if viewModel.meteringMode != .average {
                    viewModel.meteringMode = .average
                }
                withAnimation(.easeOut(duration: 0.18)) {
                    controlPanelOffset = screenWidth
                }
            } else if viewModel.meteringMode == .average {
                viewModel.meteringMode = lastReflectiveMeteringMode
            }
            cameraManager.setIncidentMode(newValue)
        }
        .onChange(of: sessionStore.selectedPresetID) { _, _ in
            cameraManager.setLensPreset(sessionStore.activePreset)
        }
        .onChange(of: sessionStore.presets) { _, _ in
            cameraManager.setLensPreset(sessionStore.activePreset)
        }
        .onChange(of: viewModel.spotBrightAreaWarningEnabled) { _, _ in
            syncSpotMeteringPreferences()
        }
        .onChange(of: viewModel.spotOffTargetWarningEnabled) { _, _ in
            syncSpotMeteringPreferences()
        }
        .onChange(of: viewModel.spotMeteringReferenceTarget) { _, _ in
            syncSpotMeteringPreferences()
        }
        .onChange(of: viewModel.spotExposureBoostPreset) { _, _ in
            syncSpotMeteringPreferences()
        }
        .onChange(of: showInitialDisplayGuide) { _, isShowing in
            if !isShowing {
                startMeterFlowIfNeeded()
            }
        }
        .onChange(of: scenePhase) { _, newPhase in
            guard newPhase == .active, hasStartedMeterFlow else { return }
            cameraManager.refreshAuthorizationStatus()
        }
        .sheet(isPresented: $showSettings) {
            SettingsView(viewModel: viewModel, cameraManager: cameraManager, sessionStore: sessionStore)
                .preferredColorScheme(viewModel.showAuxiliaryLabels ? .light : .dark)
                .presentationBackground(viewModel.showAuxiliaryLabels ? Color.meterBackground : Color.refinedBackground)
        }
        .sheet(isPresented: $showShotHistory) {
            ShotHistoryView(store: shotRecordStore, refined: !viewModel.showAuxiliaryLabels)
        }
        .fullScreenCover(isPresented: $showInitialDisplayGuide) {
            InitialDisplayModeGuideView(viewModel: viewModel, isPresented: $showInitialDisplayGuide)
        }
    }

    private func syncSpotMeteringPreferences() {
        cameraManager.updateSpotMeteringPreferences(
            brightAreaWarningEnabled: viewModel.spotBrightAreaWarningEnabled,
            offTargetWarningEnabled: viewModel.spotOffTargetWarningEnabled,
            referenceTarget: viewModel.spotMeteringReferenceTarget,
            exposureBoostPreset: viewModel.spotExposureBoostPreset
        )
    }

    private func startMeterFlowIfNeeded() {
        guard !hasStartedMeterFlow else { return }
        hasStartedMeterFlow = true

        cameraManager.startSession()
        cameraManager.setMeteringMode(viewModel.meteringMode)
        cameraManager.updateSpotMeteringPreferences(
            brightAreaWarningEnabled: viewModel.spotBrightAreaWarningEnabled,
            offTargetWarningEnabled: viewModel.spotOffTargetWarningEnabled,
            referenceTarget: viewModel.spotMeteringReferenceTarget,
            exposureBoostPreset: viewModel.spotExposureBoostPreset
        )
        cameraManager.setLensPreset(sessionStore.activePreset)

        if shouldPromptPresetSelection {
            suppressPresetPrompt = false
            withAnimation(.easeInOut(duration: 0.25)) {
                showPresetManager = true
            }
        }
    }

    private var sharedPreviewOverlay: some View {
        let frame = interpolatedPreviewFrame
        let shouldShowPreview = !viewModel.isIncidentMode
            && cameraManager.isAuthorized
            && cameraManager.isRunning
            && !cameraManager.isCameraSwitching
            && frame.width > 1
            && frame.height > 1

        return Group {
            if shouldShowPreview {
                CameraPreviewView(
                    session: cameraManager.session,
                    isActive: true,
                    onPreviewLayerUpdate: { previewLayer in
                        cameraManager.setActivePreviewLayer(previewLayer, visibleRect: activePreviewVisibleRect)
                    }
                )
                .frame(width: frame.width, height: frame.height)
                .clipShape(RoundedRectangle(cornerRadius: 3))
                .position(x: frame.midX, y: frame.midY)
                .transaction { transaction in
                    transaction.animation = nil
                }
                .allowsHitTesting(false)
            }
        }
    }

    // MARK: - Preset Overlay — プリセット選択/オンボーディングポップアップ
    private var presetOverlay: some View {
        let isOnboardingPrompt = sessionStore.activePreset == nil
        let overlayAccentColor = viewModel.showAuxiliaryLabels ? Color.meterAccent : .cyan
        let popupBorderColor = viewModel.showAuxiliaryLabels ? Color.black.opacity(0.14) : Color.white.opacity(0.12)
        return ZStack {
            LinearGradient(
                colors: [
                    Color.black.opacity(0.62),
                    Color.black.opacity(0.52)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            .overlay {
                Circle()
                    .fill(overlayAccentColor.opacity(0.10))
                    .frame(width: 360, height: 360)
                    .blur(radius: 42)
                    .offset(y: isOnboardingPrompt ? -180 : 0)
            }
            .onTapGesture {
                guard !isOnboardingPrompt else { return }
                withAnimation(.easeInOut(duration: 0.2)) {
                    showPresetManager = false
                }
            }

            Group {
                if isOnboardingPrompt {
                    PresetManagementView(
                        sessionStore: sessionStore,
                        mode: .onboarding,
                        refined: !viewModel.showAuxiliaryLabels,
                        suppressPrompt: $suppressPresetPrompt,
                        onDismiss: {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                showPresetManager = false
                            }
                        }
                    )
                    .frame(maxWidth: 460)
                    .fixedSize(horizontal: false, vertical: true)
                    .modifier(PresetPopupCardStyle(borderColor: popupBorderColor))
                    .padding(.horizontal, 24)
                    .padding(.top, 18)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                } else {
                    PresetManagementView(
                        sessionStore: sessionStore,
                        mode: .manage,
                        refined: !viewModel.showAuxiliaryLabels,
                        suppressPrompt: $suppressPresetPrompt,
                        onDismiss: {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                showPresetManager = false
                            }
                        }
                    )
                    .frame(maxWidth: 340, maxHeight: 520)
                    .modifier(PresetPopupCardStyle(borderColor: popupBorderColor))
                    .padding(.horizontal, 24)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                }
            }
        }
    }
}

private struct PresetPopupCardStyle: ViewModifier {
    let borderColor: Color

    func body(content: Content) -> some View {
        content
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(borderColor, lineWidth: 1)
            )
            .shadow(color: .black.opacity(0.38), radius: 28, y: 16)
    }
}
