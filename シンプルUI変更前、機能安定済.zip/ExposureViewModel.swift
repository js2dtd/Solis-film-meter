//
//  ExposureViewModel.swift
//  Solis film meter
//

// MARK: - 役割: 露出計の表示状態と計算結果を管理するViewModel

import SwiftUI
import Combine

@MainActor
class ExposureViewModel: ObservableObject {

    @Published var aperture: Aperture = .f5_6
    @Published var shutterSpeed: ShutterSpeed = .s125
    @Published var iso: ISOValue = .iso400
    @Published var exposureCompensation: Double = 0

    @Published var exposureMode: ExposureMode = .aperturePriority
    @Published var meteringMode: MeteringMode = .centerWeighted

    @Published var measuredEV: Double = 0
    @Published var evDifference: Double = 0
    @Published var exposureStatus: ExposureStatus = .proper

    @Published var recommendedAperture: Aperture?
    @Published var recommendedShutterSpeed: ShutterSpeed?
    @Published var isWithinRange: Bool = true
    @Published var reciprocityCorrectedTime: Double?

    @Published var isLocked: Bool = false
    @Published var showEVValue: Bool = true
    @Published var showAuxiliaryLabels: Bool = true
    @Published var enableHaptics: Bool = true {
        didSet {
            HapticManager.isEnabled = enableHaptics
        }
    }
    @Published var spotBrightAreaWarningEnabled: Bool = true
    @Published var spotOffTargetWarningEnabled: Bool = true
    @Published var spotMeteringReferenceTarget: SpotMeteringReferenceTarget = .shadow
    @Published var spotExposureBoostPreset: SpotMeteringExposureBoostPreset = .neutral
    @Published var hasSeenDisplayModeGuide: Bool = false

    @Published var isIncidentMode: Bool = false
    @Published var isPinholeMode: Bool = false

    private let lightMeter = LightMeterEngine()
    private var cancellables = Set<AnyCancellable>()

    init() {
        loadSettings()
        setupBindings()
    }

    private func setupBindings() {
        $aperture.combineLatest($shutterSpeed, $iso, $exposureCompensation)
            .sink { [weak self] _ in self?.calculateExposure() }
            .store(in: &cancellables)

        $exposureMode
            .sink { [weak self] _ in self?.calculateExposure() }
            .store(in: &cancellables)

        $measuredEV
            .sink { [weak self] _ in self?.calculateExposure() }
            .store(in: &cancellables)
    }

    private func loadSettings() {
        let settings = UserDefaults.standard.savedSettings ?? .defaultSettings
        iso = ISOValue.allCases.first { $0.rawValue == settings.defaultISO } ?? .iso400
        showEVValue = settings.showEVValue
        showAuxiliaryLabels = settings.showAuxiliaryLabels
        enableHaptics = settings.enableHaptics
        HapticManager.isEnabled = enableHaptics
        spotBrightAreaWarningEnabled = settings.spotBrightAreaWarningEnabled
        spotOffTargetWarningEnabled = settings.spotOffTargetWarningEnabled
        spotMeteringReferenceTarget = settings.spotMeteringReferenceTarget
        spotExposureBoostPreset = settings.spotExposureBoostPreset
        hasSeenDisplayModeGuide = settings.hasSeenDisplayModeGuide
        setPinholeMode(settings.isPinholeMode, emitHaptics: false)
    }

    func saveSettings() {
        let settings = SavedSettings(
            defaultISO: iso.rawValue,
            showEVValue: showEVValue,
            showAuxiliaryLabels: showAuxiliaryLabels,
            enableHaptics: enableHaptics,
            enablePinholeMode: false,
            isPinholeMode: isPinholeMode,
            spotBrightAreaWarningEnabled: spotBrightAreaWarningEnabled,
            spotOffTargetWarningEnabled: spotOffTargetWarningEnabled,
            spotMeteringReferenceTarget: spotMeteringReferenceTarget,
            spotExposureBoostPreset: spotExposureBoostPreset,
            hasSeenDisplayModeGuide: hasSeenDisplayModeGuide
        )
        UserDefaults.standard.savedSettings = settings
    }

    func markDisplayModeGuideSeenIfNeeded() {
        guard !hasSeenDisplayModeGuide else { return }
        hasSeenDisplayModeGuide = true
        saveSettings()
    }

    func updateMeasuredEV(_ ev: Double, force: Bool = false) {
        guard force || !isLocked else { return }
        measuredEV = ev
    }

    private func calculateExposure() {
        switch exposureMode {
        case .aperturePriority:
            let result = lightMeter.calculateShutterSpeed(forEV: measuredEV, aperture: aperture, iso: iso, compensation: exposureCompensation)
            recommendedShutterSpeed = result.shutterSpeed
            recommendedAperture = nil
            evDifference = result.evDifference
            isWithinRange = result.isWithinRange

        case .shutterPriority:
            let result = lightMeter.calculateAperture(forEV: measuredEV, shutterSpeed: shutterSpeed, iso: iso, compensation: exposureCompensation)
            recommendedAperture = result.aperture
            recommendedShutterSpeed = nil
            evDifference = result.evDifference
            isWithinRange = result.isWithinRange

        case .manual:
            evDifference = lightMeter.calculateEVDifference(measuredEV: measuredEV, aperture: aperture, shutterSpeed: shutterSpeed, iso: iso, compensation: exposureCompensation)
            recommendedAperture = nil
            recommendedShutterSpeed = nil
            isWithinRange = true
        }

        // 相反則不軌補正（1秒以上の場合のみ）
        let ssTime = effectiveShutterSpeed.rawValue
        if ssTime >= 1.0 {
            reciprocityCorrectedTime = pow(ssTime, 1.3)
        } else {
            reciprocityCorrectedTime = nil
        }

        updateExposureStatus()
    }

    private func updateExposureStatus() {
        if evDifference < -2.0 {
            exposureStatus = .severeUnderexposure
        } else if evDifference < -1.0 {
            exposureStatus = .underexposure
        } else if evDifference < -0.5 {
            exposureStatus = .slightUnderexposure
        } else if evDifference <= 0.5 {
            exposureStatus = .proper
        } else if evDifference <= 1.0 {
            exposureStatus = .slightOverexposure
        } else if evDifference <= 2.0 {
            exposureStatus = .overexposure
        } else {
            exposureStatus = .severeOverexposure
        }
    }

    // MARK: - ゾーンシステム — EV差分からゾーン0〜X算出
    var currentZone: Int {
        let zone = 5 + Int(round(evDifference))
        return max(0, min(10, zone))
    }

    // MARK: - 有効な撮影値 — モードに応じた実際の絞り/SS（推奨値 or 手動値）
    var effectiveAperture: Aperture {
        exposureMode == .shutterPriority ? (recommendedAperture ?? aperture) : aperture
    }

    var effectiveShutterSpeed: ShutterSpeed {
        exposureMode == .aperturePriority ? (recommendedShutterSpeed ?? shutterSpeed) : shutterSpeed
    }

    var previewAdjustmentEV: Double {
        switch exposureMode {
        case .manual:
            return softenedPreviewDifference(from: evDifference, deadZone: 0.1, scale: 1.0)
        case .aperturePriority, .shutterPriority:
            let deadZone = isWithinRange ? 0.35 : 0.15
            let scale = isWithinRange ? 0.4 : 0.75
            return softenedPreviewDifference(from: evDifference, deadZone: deadZone, scale: scale)
        }
    }

    private func softenedPreviewDifference(from value: Double, deadZone: Double, scale: Double) -> Double {
        let magnitude = abs(value)
        guard magnitude > deadZone else { return 0 }
        return (magnitude - deadZone) * scale * (value >= 0 ? 1 : -1)
    }

    // MARK: - 絞り調整 — ステップ送り（ピンホール時はf/90〜f/256範囲）
    func adjustAperture(by steps: Int, emitHaptics: Bool = true) {
        let available = isPinholeMode ? Aperture.pinholeValues : Aperture.regularValues
        guard let currentIndex = available.firstIndex(of: aperture) else {
            aperture = available.first ?? aperture
            return
        }
        let newIndex = max(0, min(available.count - 1, currentIndex + steps))
        aperture = available[newIndex]
        if emitHaptics, enableHaptics { HapticManager.shared.selectionChanged() }
    }

    func adjustShutterSpeed(by steps: Int, emitHaptics: Bool = true) {
        let allSpeeds = ShutterSpeed.allCases
        guard let currentIndex = allSpeeds.firstIndex(of: shutterSpeed) else { return }
        let newIndex = max(0, min(allSpeeds.count - 1, currentIndex - steps))
        shutterSpeed = allSpeeds[newIndex]
        if emitHaptics, enableHaptics { HapticManager.shared.selectionChanged() }
    }

    func toggleLock() {
        isLocked.toggle()
        if enableHaptics {
            isLocked ? HapticManager.shared.mediumTap() : HapticManager.shared.lightTap()
        }
    }

    func setLock(_ locked: Bool, withHaptics: Bool = false) {
        guard isLocked != locked else { return }
        isLocked = locked
        guard withHaptics, enableHaptics else { return }
        locked ? HapticManager.shared.mediumTap() : HapticManager.shared.lightTap()
    }

    // MARK: - ピンホールモード — f/90〜f/256のピンホールカメラ用絞り値に切替
    func togglePinholeMode() {
        setPinholeMode(!isPinholeMode)
    }

    func setPinholeMode(_ enabled: Bool, emitHaptics: Bool = true) {
        guard isPinholeMode != enabled else { return }
        isPinholeMode = enabled
        if enabled {
            if !Aperture.pinholeValues.contains(aperture) {
                aperture = Aperture.pinholeValues.first ?? .f128
            }
        } else if !Aperture.regularValues.contains(aperture) {
            aperture = .f16
        }
        if emitHaptics, enableHaptics { HapticManager.shared.mediumTap() }
    }

    func disablePinholeIfNeeded() {
        setPinholeMode(false, emitHaptics: false)
    }

    // MARK: - 撮影記録保存 — 現在の露出設定をShotRecordとして記録
    func saveShot(to store: ShotRecordStore, note: String = "") {
        let record = ShotRecord(
            aperture: effectiveAperture.displayString,
            shutterSpeed: effectiveShutterSpeed.displayString,
            iso: iso.rawValue,
            ev: measuredEV,
            evDifference: evDifference,
            exposureMode: exposureMode.shortName,
            meteringMode: meteringMode.displayName,
            exposureCompensation: exposureCompensation,
            isIncident: isIncidentMode,
            zoneValue: currentZone,
            note: note
        )
        store.add(record)
        if enableHaptics { HapticManager.shared.mediumTap() }
    }
}
