//
//  FullScreenMeterView.swift
//  Solis film meter
//

// MARK: - 役割: 全画面表示の露出計UI

import SwiftUI
import AVFoundation
import Photos

struct FullScreenMeterView: View {
    @ObservedObject var cameraManager: LightMeterCameraManager
    @ObservedObject var viewModel: ExposureViewModel
    @ObservedObject var shotRecordStore: ShotRecordStore
    @Binding var controlPanelOffset: CGFloat
    let screenWidth: CGFloat
    @Binding var showSettings: Bool
    @Binding var showShotHistory: Bool
    private let centerActionButtonOuterSize: CGFloat = 60
    private let centerActionButtonInnerSize: CGFloat = 48
    private let shutterButtonVerticalOffset: CGFloat = 5
    private let incidentHoldButtonVerticalOffset: CGFloat = 9

    @State private var tapPoint: CGPoint = CGPoint(x: 0.5, y: 0.5)
    @State private var tapPointOpacity: Double = 0.3
    @State private var showSaveConfirmation: Bool = false
    @State private var isSaving: Bool = false
    @State private var isPreparingShotSave: Bool = false
    @State private var pendingShotSaveDraft: PendingShotSaveDraft?
    @State private var shotSaveNote: String = ""
    @State private var zoomGestureStartFocalLength: Double?
    @State private var showSpotTapGuidancePopup: Bool = false
    @State private var hasShownSpotTapGuidanceForCurrentSpotSelection: Bool = false
    @State private var selectedSpotWarningGuide: SpotMeteringWarning?
    @State private var showThreePointMeteringGuide: Bool = false
    @State private var measuredReflectivePreviewWidth: CGFloat = 0

    private var usesRefinedInterface: Bool {
        !viewModel.showAuxiliaryLabels
    }

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                topBar()
                meterDisplayArea

                bottomControls()
            }

            // 保存完了表示
            if showSaveConfirmation {
                savedOverlay
            }

            if showSpotTapGuidancePopup {
                spotTapGuidancePopup
                    .transition(.opacity)
                    .zIndex(20)
            }

            if selectedSpotWarningGuide != nil, usesRefinedNormalUI {
                MeteringWarningGuidePopup(
                    refined: true,
                    onDismiss: dismissSpotWarningGuide
                )
                .transition(.opacity)
                .zIndex(21)
            }

            if showThreePointMeteringGuide, usesRefinedNormalUI {
                ThreePointMeteringGuidePopup(
                    refined: true,
                    onDismiss: dismissThreePointMeteringGuide
                )
                .transition(.opacity)
                .zIndex(22)
            }

            if let cameraError = cameraManager.error {
                cameraStatusOverlay(for: cameraError)
                    .transition(.opacity)
                    .zIndex(23)
            }
        }
        .ignoresSafeArea()
        .statusBarHidden()
        .sheet(item: $pendingShotSaveDraft, onDismiss: discardPendingShotSaveComposer) { _ in
            ShotSaveComposerSheet(
                note: $shotSaveNote,
                refined: usesRefinedInterface,
                isSaving: isSaving,
                onCancel: discardPendingShotSaveComposer,
                onSave: commitPendingShotSave
            )
        }
        .onAppear {
            presentSpotTapGuidanceIfNeeded()
        }
        .onChange(of: viewModel.meteringMode) { _, newValue in
            selectedSpotWarningGuide = nil
            showThreePointMeteringGuide = false
            if newValue == .spot {
                hasShownSpotTapGuidanceForCurrentSpotSelection = false
                presentSpotTapGuidanceIfNeeded()
            } else {
                showSpotTapGuidancePopup = false
                hasShownSpotTapGuidanceForCurrentSpotSelection = false
            }
        }
        .onChange(of: controlPanelOffset) { _, _ in
            presentSpotTapGuidanceIfNeeded()
        }
        .onChange(of: viewModel.isIncidentMode) { _, isIncident in
            if isIncident {
                showSpotTapGuidancePopup = false
                showThreePointMeteringGuide = false
            } else {
                presentSpotTapGuidanceIfNeeded()
            }
        }
        .onPreferenceChange(ReflectivePreviewWidthKey.self) { measuredReflectivePreviewWidth = $0 }
    }

    private var meterDisplayArea: some View {
        GeometryReader { meterGeo in
            if viewModel.isIncidentMode {
                incidentMeasurementArea(size: meterGeo.size)
            } else {
                reflectivePreviewArea(size: meterGeo.size)
            }
        }
    }

    private func reflectivePreviewArea(size: CGSize) -> some View {
        let areaWidth = max(1, size.width)
        let areaHeight = max(1, size.height)
        let previewInset: CGFloat = 16
        let availablePreviewWidth = max(1, areaWidth - (previewInset * 2))
        let availablePreviewHeight = max(1, areaHeight - (previewInset * 2))
        let previewWidth = max(1, min(availablePreviewWidth, availablePreviewHeight * 2 / 3))
        let previewHeight = max(1, previewWidth * 3 / 2)
        let previewFrame = CGRect(
            x: (areaWidth - previewWidth) / 2,
            y: (areaHeight - previewHeight) / 2,
            width: previewWidth,
            height: previewHeight
        )

        return ZStack {
            PreviewOutsideOverlayShape(cutout: previewFrame, cornerRadius: MeterShape.preview)
                .fill(
                    LinearGradient(
                        colors: [
                            usesRefinedNormalUI ? Color.refinedBackground.opacity(0.96) : Color.meterBackground.opacity(0.92),
                            usesRefinedNormalUI ? Color.refinedSurface.opacity(0.8) : Color.meterSurface.opacity(0.7)
                        ],
                        startPoint: .top,
                        endPoint: .bottom
                    ),
                    style: FillStyle(eoFill: true)
                )
                .frame(width: areaWidth, height: areaHeight)
                .allowsHitTesting(false)

            if cameraManager.isAuthorized && cameraManager.isRunning && previewWidth > 10 && previewHeight > 10 {
                RoundedRectangle(cornerRadius: MeterShape.preview)
                    .fill(Color.clear)
                    .frame(width: previewWidth, height: previewHeight)
                    .background(SharedPreviewSurfaceReporter(id: .fullscreen))
                    .overlay(previewExposureOverlay)
                    .clipShape(RoundedRectangle(cornerRadius: MeterShape.preview))
                    .overlay(
                        ZStack {
                            RoundedRectangle(cornerRadius: MeterShape.preview)
                                .stroke(viewModel.exposureStatus.color, lineWidth: 3)
                            MeteringGuideOverlay(
                                mode: viewModel.meteringMode,
                                width: previewWidth,
                                height: previewHeight,
                                spotPoint: tapPoint,
                                spotOpacity: tapPointOpacity,
                                threePointMetering: cameraManager.threePointMetering,
                                threePointSelectionMarkers: cameraManager.threePointSelectionMarkers
                            )
                        }
                    )
                    .overlay(alignment: reflectiveExposureBannerAlignment) {
                        reflectiveExposureBanner
                            .padding(.top, 12)
                            .padding(.horizontal, 12)
                            .allowsHitTesting(false)
                    }
                    .overlay {
                        if shouldShowSpotResetOverlay {
                            spotResetOverlay
                                .frame(width: previewWidth, height: previewHeight)
                                .allowsHitTesting(false)
                        }
                    }
                    .overlay(alignment: .topLeading) {
                        if shouldShowPreviewSpotWarningIndicator {
                            previewSpotWarningIndicator
                                .padding(.top, 12)
                                .padding(.leading, 12)
                        }
                    }
                    .overlay(alignment: .topTrailing) {
                        if shouldShowThreePointPairIndicator {
                            previewThreePointIndicator
                                .padding(.top, 12)
                                .padding(.trailing, 12)
                        }
                    }
                    .overlay(alignment: .bottomTrailing) {
                        if shouldShowThreePointResetButton {
                            threePointResetButton
                                .padding(.trailing, 14)
                                .padding(.bottom, 14)
                        }
                    }
                    .overlay {
                        if shouldShowSpotTapGuidanceOverlay {
                            spotTapGuidanceOverlay(
                                previewWidth: previewWidth,
                                previewHeight: previewHeight
                            )
                                .transition(.opacity)
                        }
                    }
                    .contentShape(RoundedRectangle(cornerRadius: MeterShape.preview))
                    .onTapGesture { location in
                        let relativeX = location.x / previewWidth
                        let relativeY = location.y / previewHeight
                        guard relativeX >= 0, relativeX <= 1, relativeY >= 0, relativeY <= 1 else { return }
                        handleTap(
                            location: location,
                            relativeX: relativeX,
                            relativeY: relativeY,
                            previewSize: CGSize(width: previewWidth, height: previewHeight)
                        )
                    }
                    .simultaneousGesture(fullscreenZoomGesture)
                    .background(
                        Color.clear
                            .preference(key: ReflectivePreviewWidthKey.self, value: previewWidth)
                    )
            } else {
                RoundedRectangle(cornerRadius: MeterShape.preview)
                    .fill(usesRefinedInterface ? Color.refinedSurface.opacity(0.96) : Color.black.opacity(0.5))
                    .frame(width: previewWidth, height: previewHeight)
                    .overlay {
                        VStack(spacing: 12) {
                            Image(systemName: "camera.fill")
                                .font(.system(size: 34, weight: .medium))
                            Text("カメラを準備しています")
                                .font(.meterLabel(12))
                                .tracking(1)
                        }
                        .foregroundColor(usesRefinedInterface ? .refinedTextSoft.opacity(0.74) : .meterSecondary.opacity(0.52))
                    }
            }

        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    @ViewBuilder
    private func cameraStatusOverlay(for error: CameraError) -> some View {
        ZStack {
            (usesRefinedInterface ? Color.black.opacity(0.34) : Color.black.opacity(0.22))
                .ignoresSafeArea()
            CameraStatusOverlayCard(
                error: error,
                refined: usesRefinedInterface,
                onOpenSettingsSheet: { showSettings = true },
                onOpenShotHistory: { showShotHistory = true }
            )
        }
    }

    private func formatCorrectedTime(_ seconds: Double) -> String {
        if seconds < 60 {
            return String(format: "%.0f秒", seconds)
        } else {
            let min = Int(seconds) / 60
            let sec = Int(seconds) % 60
            return sec > 0 ? "\(min)分\(sec)秒" : "\(min)分"
        }
    }

    private var reflectiveExposureBanner: some View {
        let spotWarning = cameraManager.spotMeteringWarning
        let tint = bannerTintColor(for: spotWarning)
        return Group {
            if usesRefinedNormalUI, viewModel.meteringMode != .threePoint {
                PreviewExposureDeltaReadout(
                    status: viewModel.exposureStatus,
                    evDifference: viewModel.evDifference,
                    tint: tint,
                    compact: false
                )
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(
                    Capsule()
                        .fill(Color.black.opacity(0.34))
                        .overlay(
                            Capsule()
                                .stroke(tint.opacity(0.6), lineWidth: 0.9)
                        )
                )
            } else {
                HStack(spacing: 8) {
                    if viewModel.meteringMode == .threePoint {
                        Image(systemName: "triangle")
                            .font(.system(size: 11, weight: .bold))
                        if let pendingKind = cameraManager.threePointPendingKind {
                            Text("2POINT")
                                .font(.meterValue(12))
                            if viewModel.showAuxiliaryLabels {
                                Text(threePointMeteringBannerText(for: pendingKind))
                                    .font(.meterValue(11))
                                    .opacity(0.85)
                            } else if cameraManager.measurementStateText == "安定してからタップ" {
                                Text("安定してからタップ")
                                    .font(.meterValue(11))
                                    .opacity(0.85)
                            }
                        } else if let threePoint = cameraManager.threePointMetering {
                            Text("2POINT")
                                .font(.meterValue(12))
                            Text("中間 \(String(format: "%.1f", threePoint.midtone.ev))")
                                .font(.meterValue(11))
                                .monospacedDigit()
                                .opacity(0.9)
                            Text("DR \(String(format: "%.1f", threePoint.dynamicRangeEV))EV")
                                .font(.meterValue(11))
                                .monospacedDigit()
                                .opacity(0.85)
                        } else {
                            Text("2POINT")
                                .font(.meterValue(12))
                            Text(cameraManager.measurementStateText)
                                .font(.meterValue(11))
                                .opacity(0.85)
                        }
                    } else {
                        Image(systemName: viewModel.exposureStatus.icon)
                            .font(.system(size: 12, weight: .bold))
                        Text(viewModel.exposureStatus.displayName)
                            .font(.meterValue(12))
                        if viewModel.meteringMode == .spot, spotWarning.isBrightArea, let warningText = spotWarning.detailText {
                            Text(warningText)
                                .font(.meterValue(11))
                                .opacity(0.9)
                        } else {
                            Text("\(viewModel.evDifference.evString) EV")
                                .font(.meterValue(11))
                                .monospacedDigit()
                                .opacity(0.85)
                        }
                    }
                }
                .foregroundColor(tint)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(
                    Group {
                        if usesRefinedNormalUI {
                            Capsule()
                                .fill(Color.black.opacity(0.34))
                                .overlay(
                                    Capsule()
                                        .stroke(tint.opacity(0.6), lineWidth: 0.9)
                                )
                        } else {
                            Capsule()
                                .fill(Color.meterSecondary.opacity(0.9))
                                .overlay(
                                    Capsule()
                                        .stroke(tint, lineWidth: 1)
                                )
                        }
                    }
                )
            }
        }
    }

    private var reflectiveExposureBannerAlignment: Alignment {
        usesRefinedNormalUI && viewModel.meteringMode != .threePoint ? .topTrailing : .top
    }

    private func bannerTintColor(for warning: SpotMeteringWarning) -> Color {
        if viewModel.showAuxiliaryLabels,
           viewModel.meteringMode == .threePoint,
           let pendingKind = cameraManager.threePointPendingKind {
            return threePointMeteringTint(for: pendingKind)
        }
        if viewModel.meteringMode == .spot, warning.isBrightArea {
            return .meterRed
        }
        return viewModel.exposureStatus.color
    }

    private var shouldShowSpotResetOverlay: Bool {
        !viewModel.isIncidentMode &&
        viewModel.meteringMode == .spot &&
        cameraManager.spotMeteringWarning.isBrightArea &&
        !usesRefinedNormalUI
    }

    private var currentPreviewSpotWarning: SpotMeteringWarning {
        guard !viewModel.isIncidentMode, viewModel.meteringMode == .spot else { return .none }
        return cameraManager.spotMeteringWarning
    }

    private var currentPreviewThreePointTarget: ThreePointSampleKind? {
        guard !viewModel.isIncidentMode, viewModel.meteringMode == .threePoint else { return nil }
        return cameraManager.threePointPendingKind
    }

    private var shouldShowThreePointPairIndicator: Bool {
        currentPreviewThreePointTarget != nil && usesRefinedNormalUI
    }

    private var shouldShowPreviewSpotWarningIndicator: Bool {
        if currentPreviewThreePointTarget != nil {
            return false
        }
        if usesRefinedNormalUI {
            return !viewModel.isIncidentMode && viewModel.meteringMode == .spot
        }
        return currentPreviewSpotWarning.isOffTarget
    }

    private var shouldShowThreePointResetButton: Bool {
        !viewModel.isIncidentMode &&
        viewModel.meteringMode == .threePoint &&
        cameraManager.threePointMetering != nil
    }

    private var spotResetOverlay: some View {
        ZStack {
            VStack {
                Spacer()
                HStack(spacing: 10) {
                    Image(systemName: "scope")
                        .font(.system(size: 15, weight: .medium))
                    Text("測光場所を変えてください")
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.9)
                        .multilineTextAlignment(.center)
                }
                .foregroundColor(Color.white.opacity(0.9))
                .padding(.horizontal, 14)
                .padding(.vertical, 9)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.black.opacity(0.24))
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.white.opacity(0.18), lineWidth: 0.8)
                        )
                )
                .padding(.bottom, 24)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 3))
    }

    private var previewSpotWarningIndicator: some View {
        Group {
            if usesRefinedNormalUI {
                MeteringWarningPairIndicator(
                    activeWarning: currentPreviewSpotWarning,
                    refined: usesRefinedNormalUI,
                    onTap: presentSpotWarningGuide
                )
            } else {
                MeteringWarningTextChip(
                    warning: currentPreviewSpotWarning,
                    refined: false
                )
            }
        }
    }

    private var previewThreePointIndicator: some View {
        Group {
            if let pendingTarget = currentPreviewThreePointTarget {
                Button {
                    presentThreePointMeteringGuide()
                } label: {
                    ThreePointMeteringTargetPairIndicator(
                        activeTarget: pendingTarget,
                        refined: true
                    )
                }
                .buttonStyle(.plain)
                .accessibilityLabel("2点測光ガイドを表示")
            }
        }
    }

    private var threePointResetButton: some View {
        Button {
            resetThreePointMetering()
        } label: {
            HStack(spacing: 6) {
                Image(systemName: "arrow.counterclockwise")
                    .font(.system(size: 11, weight: .bold))
                Text("再測光")
                    .font(.system(size: 10, weight: .black, design: .monospaced))
                    .tracking(0.6)
            }
            .foregroundColor(usesRefinedNormalUI ? .refinedText : .white)
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(
                Capsule()
                    .fill(usesRefinedNormalUI ? Color.black.opacity(0.32) : Color.meterSecondary.opacity(0.88))
                    .overlay(
                        Capsule()
                            .stroke((usesRefinedNormalUI ? Color.cyan : Color.meterAccent).opacity(0.72), lineWidth: 0.9)
                    )
            )
        }
        .buttonStyle(.plain)
    }

    private var autoRecommendationTint: Color {
        if viewModel.meteringMode == .spot, cameraManager.spotMeteringWarning.isBrightArea {
            return .meterRed
        }
        return .meterAccent
    }

    private var autoRecommendationBorderWidth: CGFloat {
        if viewModel.meteringMode == .spot {
            switch cameraManager.spotMeteringWarning {
            case .none:
                break
            case .brightArea:
                return 3
            case .offTarget:
                break
            }
        }
        return 1
    }

    private var isTwoPointResultReady: Bool {
        viewModel.meteringMode != .threePoint || cameraManager.threePointMetering != nil
    }

    private var autoApertureDisplayValue: String {
        guard isTwoPointResultReady else { return "--" }
        return viewModel.recommendedAperture?.displayString ?? "---"
    }

    private var autoShutterDisplayValue: String {
        guard isTwoPointResultReady else { return "--" }
        return viewModel.recommendedShutterSpeed?.displayString ?? "---"
    }

    private var autoShutterSubtitle: String? {
        guard isTwoPointResultReady else { return nil }
        return viewModel.reciprocityCorrectedTime.map { "補正:\(formatCorrectedTime($0))" }
    }

    private func incidentMeasurementArea(size: CGSize) -> some View {
        VStack(spacing: 12) {
            incidentInstructionCard
            incidentStatusPanel
            incidentEVPanel
            incidentSettingsCard

            if !viewModel.isWithinRange {
                HStack(spacing: 8) {
                    Image(systemName: "exclamationmark.triangle.fill")
                    Text("設定範囲外です")
                }
                .font(.meterLabel(11))
                .foregroundColor(.meterRed)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Capsule().fill(Color.meterRed.opacity(0.12)))
            }
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
        .frame(width: size.width, height: size.height, alignment: .center)
        .background(
            ZStack {
                LinearGradient(
                    colors: [
                        usesRefinedInterface ? Color.refinedSurface : Color.meterSurface.opacity(0.35),
                        usesRefinedInterface ? Color.refinedBackground : Color.meterBackground
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )

                Circle()
                    .fill((usesRefinedInterface ? Color.refinedPanelSoft : Color.cyan).opacity(0.08))
                    .frame(width: 260, height: 260)
                    .blur(radius: 12)
                    .offset(x: -70, y: -90)

                Circle()
                    .fill((usesRefinedInterface ? Color.refinedTextSoft : Color.meterAccent).opacity(0.09))
                    .frame(width: 220, height: 220)
                    .blur(radius: 18)
                    .offset(x: 110, y: 150)
            }
        )
    }

    // MARK: - Saved Overlay — 写真保存完了トースト
    private var savedOverlay: some View {
        VStack(spacing: 6) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 28))
            Text("保存しました")
                .font(.meterLabel(12))
        }
        .foregroundColor(.white)
        .padding(.horizontal, 24)
        .padding(.vertical, 16)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.black.opacity(0.75)))
        .transition(.opacity)
    }

    private var spotTapGuidancePopup: some View {
        ZStack {
            Color.black.opacity(0.42)
                .ignoresSafeArea()
                .onTapGesture {
                    dismissSpotTapGuidance()
                }

            VStack(alignment: .leading, spacing: 14) {
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "scope")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundColor(usesRefinedNormalUI ? .refinedText : .meterAccent)
                        .frame(width: 28, height: 28)

                    VStack(alignment: .leading, spacing: 6) {
                        Text("スポット測光のご案内")
                            .font(.meterValue(14))
                            .foregroundColor(usesRefinedNormalUI ? .refinedText : .meterSecondary)
                    }

                    Spacer(minLength: 0)
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text("画面端は AE の影響を受けやすく、測光値がずれやすくなります。")
                    Text("被写体が端にある場合も、近い明るさの場所を中央付近で測ってください。")
                }
                .font(.meterLabel(10))
                .foregroundColor(usesRefinedNormalUI ? .refinedTextSoft : .meterSecondary.opacity(0.72))

                Button {
                    dismissSpotTapGuidance()
                } label: {
                    Text("閉じる")
                        .font(.meterValue(12))
                        .foregroundColor(usesRefinedNormalUI ? .refinedTextOnDark : .black)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(usesRefinedNormalUI ? Color.refinedPanel : Color.meterAccent)
                        )
                }
                .buttonStyle(.plain)
            }
            .padding(18)
            .frame(maxWidth: 340)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(usesRefinedNormalUI ? Color.refinedSurface : Color.meterCardBg.opacity(0.98))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(usesRefinedNormalUI ? Color.refinedStroke : Color.black.opacity(0.12), lineWidth: 0.5)
                    )
                    .shadow(color: Color.black.opacity(0.24), radius: 28, x: 0, y: 12)
            )
            .padding(.horizontal, 24)
        }
    }

    private var shouldShowSpotTapGuidanceOverlay: Bool {
        (viewModel.meteringMode == .spot || viewModel.meteringMode == .threePoint) && !viewModel.isIncidentMode
    }

    private func spotTapGuidanceOverlay(previewWidth: CGFloat, previewHeight: CGFloat) -> some View {
        let cutoutRect = centerMeteringMaskRect(previewWidth: previewWidth, previewHeight: previewHeight)

        return ZStack {
            PreviewEllipseCutoutShape(cutout: cutoutRect)
                .fill(
                    Color.black.opacity(usesRefinedNormalUI ? 0.18 : 0.14),
                    style: FillStyle(eoFill: true)
                )

            Ellipse()
                .stroke(
                    Color.cyan.opacity(0.48),
                    lineWidth: 1.2
                )
                .frame(width: cutoutRect.width, height: cutoutRect.height)
                .position(x: cutoutRect.midX, y: cutoutRect.midY)
        }
        .frame(width: previewWidth, height: previewHeight)
        .allowsHitTesting(false)
    }

    private func centerMeteringMaskRect(previewWidth: CGFloat, previewHeight: CGFloat) -> CGRect {
        let cutoutWidth = min(max(previewWidth * 0.5, 148) + 30.0, previewWidth - 18)
        let cutoutHeight = min(max(previewHeight * 0.62, 184), previewHeight - 42)
        return CGRect(
            x: (previewWidth - cutoutWidth) / 2,
            y: (previewHeight - cutoutHeight) / 2 - 8,
            width: cutoutWidth,
            height: cutoutHeight
        )
    }

    private func isInsideCenterMeteringMask(_ location: CGPoint, previewSize: CGSize) -> Bool {
        let maskRect = centerMeteringMaskRect(
            previewWidth: previewSize.width,
            previewHeight: previewSize.height
        )
        guard maskRect.width > 0, maskRect.height > 0 else { return false }

        let normalizedX = (location.x - maskRect.midX) / (maskRect.width / 2)
        let normalizedY = (location.y - maskRect.midY) / (maskRect.height / 2)
        return (normalizedX * normalizedX) + (normalizedY * normalizedY) <= 1
    }

    // MARK: - Top Bar — EV値/レンズ情報/露出ステータス表示
    private func topBar() -> some View {
        ZStack {
            if viewModel.isIncidentMode {
                VStack(spacing: 6) {
                    incidentSensorAccent

                    VStack(spacing: 2) {
                        Text("INCIDENT METER")
                            .font(.meterValue(15))
                            .foregroundColor(usesRefinedInterface ? .refinedText : .cyan)
                        Text("FRONT CAMERA")
                            .font(.meterLabel(9))
                            .foregroundColor(usesRefinedInterface ? .refinedTextSoft : .meterSecondary.opacity(0.7))
                            .tracking(1.5)
                    }
                }
            } else {
                if usesRefinedNormalUI {
                    VStack(spacing: 5) {
                        Text("EV \(String(format: "%.1f", viewModel.measuredEV))")
                            .font(.meterValue(17))
                            .foregroundColor(.refinedText)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(
                                Capsule()
                                    .fill(Color.refinedSurface)
                                    .overlay(Capsule().stroke(Color.refinedStroke, lineWidth: 0.8))
                            )

                        Text(currentLensStatusText)
                            .font(.meterLabel(9))
                            .foregroundColor(.refinedTextSoft)
                            .monospacedDigit()
                            .padding(.horizontal, 10)
                            .padding(.vertical, 4)
                            .background(
                                Capsule()
                                    .fill(Color.refinedBackground)
                            )
                    }
                } else {
                    VStack(spacing: 2) {
                        Text("EV \(String(format: "%.1f", viewModel.measuredEV))")
                            .font(.meterValue(18))
                            .foregroundColor(.meterAccent)
                        Text(currentLensStatusText)
                            .font(.meterLabel(10))
                            .foregroundColor(.meterSecondary.opacity(0.7))
                            .monospacedDigit()
                    }
                }
            }

            // 左右ボタン
            HStack {
                Button { showSettings = true } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 20))
                        .foregroundColor((viewModel.isIncidentMode && usesRefinedInterface) ? .refinedText : (usesRefinedNormalUI ? .refinedText : .meterSecondary))
                }
                Spacer()
                HStack(spacing: 10) {
                    if !viewModel.isIncidentMode {
                        collapseToPanelButton
                    }
                    Button { showShotHistory = true } label: {
                        Image(systemName: "list.bullet")
                            .font(.system(size: 16))
                            .foregroundColor((viewModel.isIncidentMode && usesRefinedInterface) ? .refinedText : (usesRefinedNormalUI ? .refinedText : .meterSecondary))
                    }
                    if !viewModel.isIncidentMode && viewModel.meteringMode != .threePoint {
                        aelButton
                    }
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 56)
        .padding(.bottom, 10)
        .background((viewModel.isIncidentMode && usesRefinedInterface) ? Color.refinedSurface.opacity(0.96) : (usesRefinedNormalUI ? Color.refinedSurface.opacity(0.96) : Color.meterSurface))
    }

    private var collapseToPanelButton: some View {
        Button {
            withAnimation(.easeInOut(duration: 0.18)) {
                controlPanelOffset = 0
            }
        } label: {
            Image(systemName: "arrow.down.right.and.arrow.up.left")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(usesRefinedNormalUI ? .refinedTextOnDark : .meterSecondary)
                .frame(width: 30, height: 28)
                .background(
                    RoundedRectangle(cornerRadius: MeterShape.control)
                        .fill(usesRefinedNormalUI ? Color.refinedPanel : Color.meterButtonBg)
                        .overlay(
                            RoundedRectangle(cornerRadius: MeterShape.control)
                                .stroke(
                                    usesRefinedNormalUI ? Color.refinedStroke.opacity(0.36) : Color.black.opacity(0.1),
                                    lineWidth: 0.5
                                )
                        )
                )
        }
        .buttonStyle(.plain)
        .accessibilityLabel("小さいプレビューに戻る")
    }

    private var incidentSensorAccent: some View {
        Capsule()
            .fill(Color.cyan.opacity(0.9))
            .frame(width: 52, height: 5)
        .padding(.bottom, 2)
        .accessibilityHidden(true)
    }

    private var aelButton: some View {
        let locked = viewModel.isLocked
        let label = viewModel.isIncidentMode ? "HOLD" : "AEL"
        let isTwoPointMetering = !viewModel.isIncidentMode && viewModel.meteringMode == .threePoint
        return Button {
            guard !isTwoPointMetering else { return }
            viewModel.toggleLock()
            locked ? cameraManager.unlockExposure() : cameraManager.lockExposure()
        } label: {
            Text(label)
                .font(.system(size: 10, weight: .black, design: .monospaced))
                .tracking(1)
                .foregroundColor(
                    isTwoPointMetering
                        ? .meterSecondary.opacity(0.35)
                        : (locked ? (usesRefinedInterface ? .refinedBackground : .white) : (usesRefinedInterface ? .refinedText : .meterSecondary))
                )
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(
                    RoundedRectangle(cornerRadius: MeterShape.control)
                        .fill(
                            isTwoPointMetering
                                ? Color.meterButtonBg.opacity(0.5)
                                : (locked ? Color.cyan : (usesRefinedInterface ? Color.refinedPanel : Color.meterButtonBg))
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: MeterShape.control)
                                .stroke(
                                    locked ? Color.cyan.opacity(0.8) : (usesRefinedInterface ? Color.refinedStroke.opacity(0.7) : Color.black.opacity(0.2)),
                                    lineWidth: 0.5
                                )
                        )
                )
        }
        .buttonStyle(.plain)
        .disabled(cameraManager.isReflectiveMeasurementInProgress || isTwoPointMetering)
    }

    // MARK: - Bottom Controls — モード切替/測光モード/値調整コントロール
    private func bottomControls() -> some View {
        VStack(spacing: viewModel.isIncidentMode ? 6 : 8) {
            valueControlsRow

            if viewModel.isIncidentMode {
                incidentShutterRow
            } else {
                shutterRow
            }

            Text("右上の縮小ボタンで詳細コントロール")
                .font(.meterLabel(9))
                .foregroundColor(.meterSecondary.opacity(0.4))
                .opacity(viewModel.isIncidentMode || !viewModel.showAuxiliaryLabels ? 0 : 1)
                .offset(y: viewModel.isIncidentMode || !viewModel.showAuxiliaryLabels ? 0 : 4)
        }
        .padding(.horizontal, 12)
        .padding(.top, viewModel.isIncidentMode ? 8 : 10)
        .padding(.bottom, viewModel.isIncidentMode ? 12 : 16)
        .background(
            ((viewModel.isIncidentMode && usesRefinedInterface) ? Color.refinedSurface.opacity(0.96) : (usesRefinedNormalUI ? Color.refinedSurface.opacity(0.96) : Color.meterSurface))
                .ignoresSafeArea(.container, edges: .bottom)
        )
    }

    private var shutterRow: some View {
        GeometryReader { geo in
            let centerReservedWidth = centerActionButtonOuterSize + 28
            let sideWidth = max(0, (geo.size.width - centerReservedWidth) / 2)

            HStack(spacing: 0) {
                HStack {
                    exposureModeButtons
                    Spacer(minLength: 0)
                }
                .frame(width: sideWidth, alignment: .leading)

                shutterButton
                    .frame(width: centerReservedWidth)

                HStack {
                    Spacer(minLength: 0)
                    meteringModeButtons(maxWidth: sideWidth)
                }
                .frame(width: sideWidth, alignment: .trailing)
            }
        }
        .frame(height: centerActionButtonOuterSize + 8)
    }

    private var incidentShutterRow: some View {
        ZStack {
            incidentHoldButton

            HStack(spacing: 0) {
                exposureModeButtons
                Spacer()
                incidentFooterStatus
            }
        }
    }

    private var exposureModeButtons: some View {
        HStack(spacing: 2) {
            ForEach(ExposureMode.allCases) { mode in
                Button {
                    viewModel.exposureMode = mode
                    if viewModel.enableHaptics { HapticManager.shared.selectionChanged() }
                } label: {
                    let selected = viewModel.exposureMode == mode
                    Text(mode.shortName)
                        .font(.meterValue(11))
                        .tracking(1)
                        .foregroundColor(selected ? (usesRefinedInterface ? .refinedText : .black) : (usesRefinedInterface ? .refinedTextOnDark : .meterSecondary.opacity(0.7)))
                        .frame(width: 34, height: 28)
                        .background(
                            RoundedRectangle(cornerRadius: MeterShape.control)
                                .fill(selected ? (usesRefinedInterface ? Color.refinedSurface : Color.meterAccent) : (usesRefinedInterface ? Color.refinedPanel : Color.meterButtonBg))
                                .overlay(
                                    RoundedRectangle(cornerRadius: MeterShape.control)
                                        .stroke(
                                            selected ? (usesRefinedInterface ? Color.refinedStroke : Color.meterAccent.opacity(0.65)) : (usesRefinedInterface ? Color.refinedStroke.opacity(0.36) : Color.black.opacity(0.1)),
                                            lineWidth: 0.5
                                        )
                                )
                        )
                }
            }
        }
    }

    private func meteringModeButtons(maxWidth: CGFloat) -> some View {
        Menu {
            Section("測光モード") {
                ForEach(MeteringMode.allCases) { mode in
                    Button {
                        handleMeteringModeSelection(mode)
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: mode.icon)
                                .font(.system(size: 12, weight: .semibold))
                                .frame(width: 14, height: 14)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(mode.displayName)
                                    .font(.system(size: 12, weight: .semibold))
                                if viewModel.showAuxiliaryLabels {
                                    Text(mode.shortDescription)
                                        .font(.system(size: 10, weight: .medium))
                                }
                            }
                            Spacer(minLength: 8)
                            if viewModel.meteringMode == mode {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 11, weight: .bold))
                            }
                        }
                    }
                }
            }

            if viewModel.meteringMode == .spot {
                Section("スポット測光の基準") {
                    ForEach(SpotMeteringReferenceTarget.allCases) { target in
                        Button {
                            viewModel.spotMeteringReferenceTarget = target
                            if viewModel.enableHaptics { HapticManager.shared.selectionChanged() }
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: target.iconName)
                                    .font(.system(size: 12, weight: .semibold))
                                    .frame(width: 14, height: 14)
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(target.title)
                                        .font(.system(size: 12, weight: .semibold))
                                    if viewModel.showAuxiliaryLabels {
                                        Text(target.detailText)
                                            .font(.system(size: 10, weight: .medium))
                                            .lineLimit(2)
                                    }
                                }
                                Spacer(minLength: 8)
                                if viewModel.spotMeteringReferenceTarget == target {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 11, weight: .bold))
                                }
                            }
                        }
                    }
                }
            }
        } label: {
            let controlWidth = min(meteringModeControlWidth, maxWidth)
            HStack(spacing: 6) {
                Image(systemName: viewModel.meteringMode == .threePoint ? "triangle" : viewModel.meteringMode.icon)
                    .font(.system(size: 13, weight: .semibold))
                    .frame(width: 16, height: 16)

                VStack(alignment: .leading, spacing: 1) {
                    Text(viewModel.showAuxiliaryLabels ? viewModel.meteringMode.displayName : viewModel.meteringMode.compactLabel)
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .tracking(0.4)
                        .lineLimit(1)
                        .minimumScaleFactor(0.66)
                        .layoutPriority(1)
                    Text(meteringModeSummaryText)
                        .font(.system(size: 8, weight: .medium, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.58)
                }
                .layoutPriority(1)

                Spacer(minLength: 2)

                if viewModel.meteringMode == .spot {
                    Image(systemName: viewModel.spotMeteringReferenceTarget.iconName)
                        .font(.system(size: 10, weight: .semibold))
                        .frame(width: 14, height: 14)
                }

                Image(systemName: "chevron.up.chevron.down")
                    .font(.system(size: 9, weight: .bold))
            }
            .foregroundColor(usesRefinedNormalUI ? .refinedTextOnDark : .meterSecondary)
            .padding(.horizontal, 10)
            .frame(width: controlWidth, height: 36)
            .background(
                RoundedRectangle(cornerRadius: MeterShape.control)
                    .fill(usesRefinedNormalUI ? Color.refinedPanel : Color.meterButtonBg)
                    .overlay(
                        RoundedRectangle(cornerRadius: MeterShape.control)
                            .stroke(
                                usesRefinedNormalUI ? Color.refinedStroke.opacity(0.42) : Color.black.opacity(0.12),
                                lineWidth: 0.5
                            )
                    )
            )
        }
        .buttonStyle(.plain)
        .disabled(cameraManager.isReflectiveMeasurementInProgress)
    }

    private var meteringModeControlWidth: CGFloat {
        min(max(screenWidth * 0.41, 148), 164)
    }

    private var meteringModeSummaryText: String {
        if viewModel.meteringMode == .spot {
            return viewModel.showAuxiliaryLabels
                ? "基準 \(viewModel.spotMeteringReferenceTarget.shortTitle)"
                : viewModel.spotMeteringReferenceTarget.shortTitle
        }
        return viewModel.showAuxiliaryLabels
            ? viewModel.meteringMode.shortDescription
            : viewModel.meteringMode.shortDescription
    }

    private var valueControlsRow: some View {
        let isAv = viewModel.exposureMode == .aperturePriority
        let isTv = viewModel.exposureMode == .shutterPriority
        return GeometryReader { geo in
            let spacing: CGFloat = 4
            let rowWidth = min(geo.size.width, fullscreenValueCardRowWidth)
            let widths = valueCardWidths(totalWidth: rowWidth, spacing: spacing)

            HStack(spacing: spacing) {
                CompactValueControl(
                    title: "絞り",
                    value: isTv ? autoApertureDisplayValue : currentAperture.displayString,
                    showTitle: viewModel.showAuxiliaryLabels,
                    refined: usesRefinedInterface,
                    presentation: .fullscreen,
                    isAuto: isTv,
                    autoTint: autoRecommendationTint,
                    autoBorderLineWidth: autoRecommendationBorderWidth,
                    isEnabled: !isTv,
                    isCalculated: isTv,
                    onIncrement: { viewModel.adjustAperture(by: 1, emitHaptics: false) },
                    onDecrement: { viewModel.adjustAperture(by: -1, emitHaptics: false) }
                )
                .frame(width: widths[0])
                CompactValueControl(
                    title: "SS",
                    value: isAv ? autoShutterDisplayValue : currentShutterSpeed.displayString,
                    subtitle: isAv ? autoShutterSubtitle : viewModel.reciprocityCorrectedTime.map { "補正:\(formatCorrectedTime($0))" },
                    showTitle: viewModel.showAuxiliaryLabels,
                    refined: usesRefinedInterface,
                    presentation: .fullscreen,
                    isAuto: isAv,
                    autoTint: autoRecommendationTint,
                    autoBorderLineWidth: autoRecommendationBorderWidth,
                    isEnabled: !isAv,
                    isCalculated: isAv,
                    onIncrement: { viewModel.adjustShutterSpeed(by: 1, emitHaptics: false) },
                    onDecrement: { viewModel.adjustShutterSpeed(by: -1, emitHaptics: false) }
                )
                .frame(width: widths[1])
                CompactValueControl(
                    title: "ISO",
                    value: "\(viewModel.iso.rawValue)",
                    showTitle: viewModel.showAuxiliaryLabels,
                    refined: usesRefinedInterface,
                    presentation: .fullscreen,
                    isEnabled: true,
                    isCalculated: false,
                    onIncrement: { adjustISO(by: 1, emitHaptics: false) },
                    onDecrement: { adjustISO(by: -1, emitHaptics: false) }
                )
                .frame(width: widths[2])
            }
            .frame(width: rowWidth)
            .animation(.easeInOut(duration: 0.2), value: viewModel.exposureMode)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        }
        .frame(height: viewModel.showAuxiliaryLabels ? 96 : 88)
    }

    private var fullscreenValueCardRowWidth: CGFloat {
        max(270, measuredReflectivePreviewWidth > 0 ? measuredReflectivePreviewWidth : screenWidth - 32)
    }

    private var valueCardWeights: [CGFloat] {
        switch viewModel.exposureMode {
        case .manual:
            return [1, 1, 1]
        case .aperturePriority:
            return [1.06, 0.94, 1.06]
        case .shutterPriority:
            return [0.94, 1.06, 1.06]
        }
    }

    private func valueCardWidths(totalWidth: CGFloat, spacing: CGFloat) -> [CGFloat] {
        let weights = valueCardWeights
        let usableWidth = max(0, totalWidth - spacing * CGFloat(weights.count - 1))
        let totalWeight = weights.reduce(0, +)
        return weights.map { usableWidth * ($0 / totalWeight) }
    }

    private var incidentInstructionCard: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("手順")
                .font(.meterValue(11))
                .foregroundColor(usesRefinedInterface ? .refinedText : .meterSecondary)

            VStack(alignment: .leading, spacing: 4) {
                incidentInstructionRow(number: "1", text: "フロントカメラを被写体に近づけ、光源側へ向ける")
                incidentInstructionRow(number: "2", text: "カメラ周辺を手やケースで遮らない")
                incidentInstructionRow(number: "3", text: "値が安定したら HOLD")
            }
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(usesRefinedInterface ? Color.refinedSurface : Color.meterCardBg.opacity(0.95))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(usesRefinedInterface ? Color.refinedStroke : Color.black.opacity(0.12), lineWidth: 0.5))
        )
    }

    private var incidentStatusPanel: some View {
        VStack(spacing: 8) {
            HStack {
                Text("測定状態")
                    .font(.meterLabel(9))
                    .foregroundColor(usesRefinedInterface ? .refinedTextSoft : .meterSecondary.opacity(0.65))
                Spacer()
                Text(viewModel.isLocked ? "値を保持中" : cameraManager.measurementStateText)
                    .font(.meterValue(10))
                    .foregroundColor(incidentStateColor)
            }

            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(usesRefinedInterface ? Color.refinedPanel : Color.meterSecondary.opacity(0.15))
                    RoundedRectangle(cornerRadius: 2)
                        .fill(incidentStateColor)
                        .frame(width: max(4, geo.size.width * cameraManager.measurementStability))
                }
            }
            .frame(height: 4)
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(usesRefinedInterface ? Color.refinedSurface : Color.meterCardBg.opacity(0.95))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(usesRefinedInterface ? Color.refinedStroke : Color.black.opacity(0.12), lineWidth: 0.5))
        )
    }

    private var incidentEVPanel: some View {
        VStack(spacing: 4) {
            Text("EV")
                .font(.meterLabel(11))
                .foregroundColor(usesRefinedInterface ? .refinedTextSoft : .meterSecondary.opacity(0.6))
                .tracking(2)

            Text(String(format: "%.1f", viewModel.measuredEV))
                .font(.system(size: 56, weight: .black, design: .monospaced))
                .foregroundColor(usesRefinedInterface ? .cyan : .meterAccent)
                .minimumScaleFactor(0.6)
                .lineLimit(1)

            Text(viewModel.exposureStatus.displayName)
                .font(.meterValue(11))
                .foregroundColor(viewModel.exposureStatus.color)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(
            RoundedRectangle(cornerRadius: 14)
                .fill(usesRefinedInterface ? Color.refinedPanel : Color.meterSurface.opacity(0.85))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke((usesRefinedInterface ? Color.cyan : viewModel.exposureStatus.color).opacity(0.35), lineWidth: 1))
        )
    }

    private var incidentRecommendationRow: some View {
        HStack(spacing: 10) {
            incidentValueCard(
                title: incidentApertureIsCalculated ? "推奨 F" : "F",
                value: currentAperture.displayString,
                tint: incidentApertureIsCalculated ? (usesRefinedInterface ? .cyan : .meterAccent) : (usesRefinedInterface ? .refinedText : .meterSecondary),
                isCalculated: incidentApertureIsCalculated
            )
            incidentValueCard(
                title: incidentShutterIsCalculated ? "推奨 SS" : "SS",
                value: currentShutterSpeed.displayString,
                tint: incidentShutterIsCalculated ? (usesRefinedInterface ? .cyan : .meterAccent) : (usesRefinedInterface ? .refinedText : .meterSecondary),
                isCalculated: incidentShutterIsCalculated
            )
            incidentValueCard(
                title: "ISO",
                value: "\(viewModel.iso.rawValue)",
                tint: usesRefinedInterface ? .refinedText : .meterSecondary,
                isCalculated: false
            )
        }
    }

    private var incidentFooterStatus: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(incidentStateColor)
                .frame(width: 7, height: 7)
            Text(incidentStatusText)
                .font(.system(size: 8, weight: .black, design: .monospaced))
                .tracking(0.8)
                .foregroundColor(incidentStateColor)
        }
        .padding(.horizontal, 9)
        .padding(.vertical, 6)
        .background(
            Capsule()
                .fill(usesRefinedInterface ? Color.refinedPanel : Color.meterSecondary.opacity(0.85))
                .overlay(Capsule().stroke(incidentStateColor.opacity(0.5), lineWidth: 0.6))
        )
    }

    private var incidentStateBadge: some View {
        Text(incidentStatusText)
            .font(.system(size: 8, weight: .black, design: .monospaced))
            .tracking(0.8)
            .foregroundColor(incidentStateColor)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                Capsule()
                    .fill(incidentStateColor.opacity(0.12))
                    .overlay(Capsule().stroke(incidentStateColor.opacity(0.35), lineWidth: 0.6))
            )
    }

    private func incidentInstructionRow(number: String, text: String) -> some View {
        HStack(alignment: .top, spacing: 7) {
            Text(number)
                .font(.system(size: 9, weight: .black, design: .monospaced))
                .foregroundColor(.black)
                .frame(width: 16, height: 16)
                .background(Circle().fill(Color.cyan.opacity(0.75)))
            Text(text)
                .font(.meterLabel(10))
                .foregroundColor(usesRefinedInterface ? .refinedTextSoft : .meterSecondary.opacity(0.82))
            Spacer(minLength: 0)
        }
    }

    private var incidentApertureIsCalculated: Bool {
        viewModel.exposureMode == .shutterPriority
    }

    private var incidentShutterIsCalculated: Bool {
        viewModel.exposureMode == .aperturePriority
    }

    private func incidentValueCard(title: String, value: String, tint: Color, isCalculated: Bool) -> some View {
        VStack(spacing: 6) {
            Text(title)
                .font(.meterLabel(10))
                .foregroundColor(isCalculated ? ((usesRefinedInterface ? Color.cyan : Color.meterAccent).opacity(0.8)) : (usesRefinedInterface ? .refinedTextSoft : .meterSecondary.opacity(0.6)))
            Text(value)
                .font(.system(size: 24, weight: .black, design: .monospaced))
                .foregroundColor(tint)
                .minimumScaleFactor(0.55)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(usesRefinedInterface ? Color.refinedSurface : Color.meterCardBg.opacity(0.95))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke((usesRefinedInterface ? tint.opacity(0.32) : tint.opacity(0.2)), lineWidth: 0.8))
        )
    }

    private var incidentHoldButton: some View {
        let locked = viewModel.isLocked
        return Button {
            viewModel.toggleLock()
            locked ? cameraManager.unlockExposure() : cameraManager.lockExposure()
        } label: {
            ZStack {
                Circle()
                    .strokeBorder(locked ? (usesRefinedInterface ? Color.cyan : Color.meterAccent) : (usesRefinedInterface ? Color.refinedStroke : Color.meterSecondary), lineWidth: 3)
                    .frame(width: centerActionButtonOuterSize, height: centerActionButtonOuterSize)
                Circle()
                    .fill(locked ? (usesRefinedInterface ? Color.cyan : Color.meterAccent) : (usesRefinedInterface ? Color.refinedSurface : Color.meterSecondary))
                    .frame(width: centerActionButtonInnerSize, height: centerActionButtonInnerSize)
                Text("HOLD")
                    .font(.system(size: 10, weight: .black, design: .monospaced))
                    .tracking(0.8)
                    .foregroundColor(
                        usesRefinedInterface
                            ? (locked ? .refinedBackground : .refinedText)
                            : .meterBackground
                    )
            }
        }
        .buttonStyle(.plain)
        .offset(y: incidentHoldButtonVerticalOffset)
    }

    private var incidentSettingsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("設定")
                .font(.meterValue(11))
                .foregroundColor(usesRefinedInterface ? .refinedText : .meterSecondary)

            ExposureCompensationSlider(value: $viewModel.exposureCompensation, refined: usesRefinedInterface)

            Button {
                viewModel.isIncidentMode = false
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "arrow.triangle.2.circlepath.camera")
                        .font(.system(size: 13, weight: .semibold))
                    Text("反射光測定に戻る")
                        .font(.meterLabel(11))
                    Spacer()
                    Text("REFLECTIVE")
                        .font(.system(size: 8, weight: .black, design: .monospaced))
                        .tracking(0.6)
                }
                .foregroundColor(usesRefinedInterface ? .refinedText : .meterSecondary)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(usesRefinedInterface ? Color.refinedPanel : Color.meterSurface.opacity(0.65))
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(usesRefinedInterface ? Color.refinedStroke : Color.black.opacity(0.12), lineWidth: 0.5)
                        )
                )
            }
            .buttonStyle(.plain)
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(usesRefinedInterface ? Color.refinedSurface : Color.meterCardBg.opacity(0.95))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(usesRefinedInterface ? Color.refinedStroke : Color.black.opacity(0.12), lineWidth: 0.5))
        )
    }

    // MARK: - Shutter Button — シャッター/HOLD切替ボタン
    private var shutterButton: some View {
        let isBusy = isSaving || isPreparingShotSave
        let strokeColor = usesRefinedNormalUI
            ? Color.cyan.opacity(isBusy ? 0.42 : 0.95)
            : Color.meterSecondary
        let outerFillColor = usesRefinedNormalUI
            ? Color.refinedPanel.opacity(isBusy ? 0.55 : 0.92)
            : .clear
        let innerFillColor = usesRefinedNormalUI
            ? Color.cyan.opacity(isBusy ? 0.34 : 0.98)
            : (isBusy ? Color.meterSecondary.opacity(0.3) : Color.meterSecondary)

        return Button {
            guard !isBusy else { return }
            beginShotSaveFlow()
        } label: {
            ZStack {
                Circle()
                    .fill(outerFillColor)
                    .frame(width: centerActionButtonOuterSize, height: centerActionButtonOuterSize)
                Circle()
                    .strokeBorder(strokeColor, lineWidth: usesRefinedNormalUI ? 3.4 : 3)
                    .frame(width: centerActionButtonOuterSize, height: centerActionButtonOuterSize)
                Circle()
                    .fill(innerFillColor)
                    .frame(width: centerActionButtonInnerSize, height: centerActionButtonInnerSize)
                    .overlay {
                        if usesRefinedNormalUI {
                            Circle()
                                .stroke(Color.white.opacity(0.16), lineWidth: 0.8)
                        }
                    }
                    .shadow(
                        color: usesRefinedNormalUI ? Color.cyan.opacity(isBusy ? 0.0 : 0.24) : .clear,
                        radius: 10,
                        x: 0,
                        y: 4
                    )
            }
        }
        .buttonStyle(.plain)
        .offset(y: shutterButtonVerticalOffset)
    }

    // MARK: - Capture & Save — コラージュ画像生成→写真ライブラリ保存
    private func beginShotSaveFlow() {
        isPreparingShotSave = true
        cameraManager.captureCurrentPreviewImage { previewImage in
            defer { isPreparingShotSave = false }
            guard let previewImage else { return }
            pendingShotSaveDraft = makePendingShotSaveDraft(previewImage: previewImage)
            shotSaveNote = ""
        }
    }

    private func makePendingShotSaveDraft(previewImage: CGImage) -> PendingShotSaveDraft {
        PendingShotSaveDraft(
            previewImage: previewImage,
            capturedAt: Date(),
            aperture: currentAperture.displayString,
            shutterSpeed: currentShutterSpeed.displayString,
            iso: viewModel.iso.rawValue,
            ev: viewModel.measuredEV,
            evDifference: viewModel.evDifference,
            exposureMode: viewModel.exposureMode.shortName,
            meteringMode: viewModel.meteringMode.displayName,
            exposureCompensation: viewModel.exposureCompensation,
            isIncident: viewModel.isIncidentMode,
            zoneValue: viewModel.currentZone,
            exposureStatus: viewModel.exposureStatus
        )
    }

    private func discardPendingShotSaveComposer() {
        pendingShotSaveDraft = nil
        shotSaveNote = ""
    }

    private func commitPendingShotSave() {
        guard let draft = pendingShotSaveDraft, !isSaving else { return }

        let normalizedNote = shotSaveNote.trimmingCharacters(in: .whitespacesAndNewlines)

        isSaving = true

        let record = ShotRecord(
            aperture: draft.aperture,
            shutterSpeed: draft.shutterSpeed,
            iso: draft.iso,
            ev: draft.ev,
            evDifference: draft.evDifference,
            exposureMode: draft.exposureMode,
            meteringMode: draft.meteringMode,
            exposureCompensation: draft.exposureCompensation,
            isIncident: draft.isIncident,
            zoneValue: draft.zoneValue,
            note: normalizedNote,
            date: draft.capturedAt
        )
        shotRecordStore.add(record)
        if viewModel.enableHaptics { HapticManager.shared.mediumTap() }

        let collageImage = generateCollage(for: draft, note: normalizedNote)
        record.saveCollageImage(collageImage)

        pendingShotSaveDraft = nil
        shotSaveNote = ""

        PHPhotoLibrary.requestAuthorization(for: .addOnly) { status in
            guard status == .authorized || status == .limited else {
                DispatchQueue.main.async { isSaving = false }
                return
            }

            var createdPhotoAssetLocalIdentifier: String?

            PHPhotoLibrary.shared().performChanges {
                if let data = collageImage.pngData() {
                    let request = PHAssetCreationRequest.forAsset()
                    request.addResource(with: .photo, data: data, options: nil)
                    createdPhotoAssetLocalIdentifier = request.placeholderForCreatedAsset?.localIdentifier
                }
            } completionHandler: { success, _ in
                DispatchQueue.main.async {
                    isSaving = false
                    if success {
                        if let createdPhotoAssetLocalIdentifier {
                            shotRecordStore.updatePhotoAssetLocalIdentifier(createdPhotoAssetLocalIdentifier, for: record.id)
                        }
                        withAnimation { showSaveConfirmation = true }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                            withAnimation { showSaveConfirmation = false }
                        }
                    }
                }
            }
        }
    }

    // MARK: - Collage Generator — プレビュー+露出情報のコラージュ画像描画
    private func generateCollage(for draft: PendingShotSaveDraft, note: String) -> UIImage {
        let totalWidth: CGFloat = 800
        let totalHeight: CGFloat = 600

        let renderer = UIGraphicsImageRenderer(size: CGSize(width: totalWidth, height: totalHeight))
        return renderer.image { ctx in
            let context = ctx.cgContext

            UIColor(white: 0.12, alpha: 1).setFill()
            context.fill(CGRect(x: 0, y: 0, width: totalWidth, height: totalHeight))

            let rotatedImage = UIImage(
                cgImage: draft.previewImage,
                scale: 1.0,
                orientation: viewModel.isIncidentMode ? .rightMirrored : .right
            )

            let outerPadding: CGFloat = 28
            let panelGap: CGFloat = 24
            let photoCardWidth: CGFloat = 300
            let photoCardHeight: CGFloat = photoCardWidth * 3 / 2
            let photoCardRect = CGRect(
                x: outerPadding,
                y: (totalHeight - photoCardHeight) / 2,
                width: photoCardWidth,
                height: photoCardHeight
            )
            let photoRect = photoCardRect.insetBy(dx: 8, dy: 8)
            let rightPanelX = photoCardRect.maxX + panelGap
            let rightPanelWidth = totalWidth - rightPanelX - outerPadding

            let photoCardPath = UIBezierPath(roundedRect: photoCardRect, cornerRadius: 20)
            context.setFillColor(UIColor(white: 0.09, alpha: 1).cgColor)
            context.addPath(photoCardPath.cgPath)
            context.fillPath()
            context.addPath(photoCardPath.cgPath)
            context.setStrokeColor(UIColor(white: 0.20, alpha: 1).cgColor)
            context.setLineWidth(1)
            context.strokePath()

            let imgSize = rotatedImage.size
            let scaleX = photoRect.width / imgSize.width
            let scaleY = photoRect.height / imgSize.height
            let fillScale = max(scaleX, scaleY)
            let drawW = imgSize.width * fillScale
            let drawH = imgSize.height * fillScale
            let drawX = photoRect.minX + (photoRect.width - drawW) / 2
            let drawY = photoRect.minY + (photoRect.height - drawH) / 2

            context.saveGState()
            let photoClipPath = UIBezierPath(roundedRect: photoRect, cornerRadius: 16)
            context.addPath(photoClipPath.cgPath)
            context.clip()
            rotatedImage.draw(in: CGRect(x: drawX, y: drawY, width: drawW, height: drawH))
            context.restoreGState()

            let valueFont = UIFont.monospacedSystemFont(ofSize: 24, weight: .bold)
            let detailFont = UIFont.monospacedSystemFont(ofSize: 13, weight: .semibold)
            let metaFont = UIFont.monospacedSystemFont(ofSize: 11, weight: .medium)
            let noteTitleFont = UIFont.monospacedSystemFont(ofSize: 11, weight: .bold)
            let noteFont = UIFont.systemFont(ofSize: 14, weight: .medium)
            let footerFont = UIFont.monospacedSystemFont(ofSize: 10, weight: .regular)
            let accentColor = UIColor(red: 0.95, green: 0.36, blue: 0.14, alpha: 1)
            let shutterColor = UIColor(red: 0.56, green: 0.84, blue: 0.94, alpha: 1)
            let isoColor = UIColor(red: 0.95, green: 0.89, blue: 0.70, alpha: 1)
            let grayColor = UIColor(white: 0.70, alpha: 1)
            let subduedColor = UIColor(white: 0.52, alpha: 1)
            let noteColor = UIColor(white: 0.92, alpha: 1)
            let noteBoxStroke = UIColor(white: 0.22, alpha: 1)
            let noteBoxFill = UIColor(white: 0.11, alpha: 1)

            let sidePadding: CGFloat = rightPanelX
            let columnGap: CGFloat = 12
            let tripleColumnWidth = (rightPanelWidth - columnGap * 2) / 3
            let dualColumnWidth = (rightPanelWidth - columnGap) / 2

            let y1: CGFloat = outerPadding + 6
            let y2: CGFloat = y1 + 38
            let dividerY: CGFloat = y2 + 28
            let y3: CGFloat = dividerY + 16
            let noteHeaderY: CGFloat = y3 + 28
            let noteBoxY: CGFloat = noteHeaderY + 22
            let y4: CGFloat = totalHeight - outerPadding - 14
            let noteBoxHeight = y4 - noteBoxY - 22

            drawText(
                draft.aperture,
                in: CGRect(x: sidePadding, y: y1, width: tripleColumnWidth, height: 34),
                font: valueFont,
                color: accentColor,
                in: context
            )
            drawText(
                draft.shutterSpeed,
                in: CGRect(x: sidePadding + tripleColumnWidth + columnGap, y: y1, width: tripleColumnWidth, height: 34),
                font: valueFont,
                color: shutterColor,
                in: context
            )
            drawText(
                "ISO \(draft.iso)",
                in: CGRect(x: sidePadding + (tripleColumnWidth + columnGap) * 2, y: y1, width: tripleColumnWidth, height: 34),
                font: valueFont,
                color: isoColor,
                in: context
            )

            drawText(
                "EV \(String(format: "%.1f", draft.ev))",
                in: CGRect(x: sidePadding, y: y2, width: tripleColumnWidth, height: 18),
                font: detailFont,
                color: accentColor,
                in: context
            )
            drawText(
                draft.exposureStatus.displayName,
                in: CGRect(x: sidePadding + tripleColumnWidth + columnGap, y: y2, width: tripleColumnWidth, height: 18),
                font: detailFont,
                color: collageExposureStatusColor(for: draft.exposureStatus),
                in: context
            )
            drawText(
                "Zone \(draft.zoneValue)",
                in: CGRect(x: sidePadding + (tripleColumnWidth + columnGap) * 2, y: y2, width: tripleColumnWidth, height: 18),
                font: detailFont,
                color: grayColor,
                in: context
            )

            context.setStrokeColor(UIColor(white: 0.18, alpha: 1).cgColor)
            context.setLineWidth(1)
            context.move(to: CGPoint(x: sidePadding, y: dividerY))
            context.addLine(to: CGPoint(x: sidePadding + rightPanelWidth, y: dividerY))
            context.strokePath()

            let compStr = draft.exposureCompensation == 0
                ? "±0 EV"
                : String(format: "%+.1f EV", draft.exposureCompensation)
            drawText(
                "\(draft.exposureMode) / \(draft.meteringMode)",
                in: CGRect(x: sidePadding, y: y3, width: dualColumnWidth, height: 14),
                font: metaFont,
                color: grayColor,
                in: context
            )
            drawText(
                compStr,
                in: CGRect(x: sidePadding + dualColumnWidth + columnGap, y: y3, width: dualColumnWidth, height: 14),
                font: metaFont,
                color: grayColor,
                alignment: .right,
                in: context
            )

            drawText(
                "NOTE",
                in: CGRect(x: sidePadding, y: noteHeaderY, width: dualColumnWidth, height: 14),
                font: noteTitleFont,
                color: grayColor,
                in: context
            )

            let noteRect = CGRect(x: sidePadding, y: noteBoxY, width: rightPanelWidth, height: noteBoxHeight)
            let notePath = UIBezierPath(roundedRect: noteRect, cornerRadius: 14)
            context.setFillColor(noteBoxFill.cgColor)
            context.addPath(notePath.cgPath)
            context.fillPath()
            context.addPath(notePath.cgPath)
            context.setStrokeColor(noteBoxStroke.cgColor)
            context.setLineWidth(1)
            context.strokePath()

            let noteContentRect = noteRect.insetBy(dx: 14, dy: 12)
            let renderedNote = note.isEmpty
                ? "記録メモなし"
                : fittedCollageNote(note, in: noteContentRect, font: noteFont, lineSpacing: 4)

            drawParagraphText(
                renderedNote,
                in: noteContentRect,
                font: noteFont,
                color: note.isEmpty ? subduedColor : noteColor,
                lineSpacing: 4,
                in: context
            )

            drawText(
                "Solis film meter",
                in: CGRect(x: sidePadding, y: y4, width: dualColumnWidth, height: 12),
                font: footerFont,
                color: subduedColor,
                in: context
            )

            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy.MM.dd HH:mm"
            let dateStr = formatter.string(from: draft.capturedAt)
            drawText(
                dateStr,
                in: CGRect(x: sidePadding + dualColumnWidth + columnGap, y: y4, width: dualColumnWidth, height: 12),
                font: footerFont,
                color: subduedColor,
                alignment: .right,
                in: context
            )
        }
    }

    private func drawText(_ text: String, at point: CGPoint, font: UIFont, color: UIColor, in context: CGContext) {
        let attrs: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: color
        ]
        (text as NSString).draw(at: point, withAttributes: attrs)
    }

    private func drawText(
        _ text: String,
        in rect: CGRect,
        font: UIFont,
        color: UIColor,
        alignment: NSTextAlignment = .left,
        in context: CGContext
    ) {
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = alignment

        let attrs: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: color,
            .paragraphStyle: paragraph
        ]
        (text as NSString).draw(in: rect, withAttributes: attrs)
    }

    private func drawParagraphText(
        _ text: String,
        in rect: CGRect,
        font: UIFont,
        color: UIColor,
        alignment: NSTextAlignment = .left,
        lineSpacing: CGFloat = 0,
        in context: CGContext
    ) {
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = alignment
        paragraph.lineBreakMode = .byCharWrapping
        paragraph.lineSpacing = lineSpacing

        let attrs: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: color,
            .paragraphStyle: paragraph
        ]
        let attributed = NSAttributedString(string: text, attributes: attrs)
        attributed.draw(
            with: rect,
            options: [.usesLineFragmentOrigin, .usesFontLeading],
            context: nil
        )
    }

    private func fittedCollageNote(
        _ text: String,
        in rect: CGRect,
        font: UIFont,
        lineSpacing: CGFloat
    ) -> String {
        let trimmedText = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedText.isEmpty else { return "" }

        if paragraphTextHeight(for: trimmedText, width: rect.width, font: font, lineSpacing: lineSpacing) <= rect.height {
            return trimmedText
        }

        let characters = Array(trimmedText)
        var low = 0
        var high = characters.count

        while low < high {
            let mid = (low + high + 1) / 2
            let candidate = String(characters.prefix(mid)).trimmingCharacters(in: .whitespacesAndNewlines)
            if paragraphTextHeight(for: candidate, width: rect.width, font: font, lineSpacing: lineSpacing) <= rect.height {
                low = mid
            } else {
                high = mid - 1
            }
        }

        return String(characters.prefix(low)).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func paragraphTextHeight(
        for text: String,
        width: CGFloat,
        font: UIFont,
        lineSpacing: CGFloat
    ) -> CGFloat {
        guard !text.isEmpty else { return 0 }

        let paragraph = NSMutableParagraphStyle()
        paragraph.lineBreakMode = .byCharWrapping
        paragraph.lineSpacing = lineSpacing

        let attrs: [NSAttributedString.Key: Any] = [
            .font: font,
            .paragraphStyle: paragraph
        ]
        let attributed = NSAttributedString(string: text, attributes: attrs)
        let bounds = attributed.boundingRect(
            with: CGSize(width: width, height: .greatestFiniteMagnitude),
            options: [.usesLineFragmentOrigin, .usesFontLeading],
            context: nil
        )
        return ceil(bounds.height)
    }

    private func collageExposureStatusColor(for status: ExposureStatus) -> UIColor {
        switch status {
        case .severeUnderexposure:
            return UIColor(red: 0.34, green: 0.58, blue: 0.96, alpha: 1)
        case .underexposure:
            return UIColor(red: 0.44, green: 0.82, blue: 0.95, alpha: 1)
        case .slightUnderexposure:
            return UIColor(red: 0.43, green: 0.84, blue: 0.73, alpha: 1)
        case .proper:
            return UIColor(red: 0.55, green: 0.84, blue: 0.48, alpha: 1)
        case .slightOverexposure:
            return UIColor(red: 0.95, green: 0.82, blue: 0.42, alpha: 1)
        case .overexposure:
            return UIColor(red: 0.95, green: 0.57, blue: 0.22, alpha: 1)
        case .severeOverexposure:
            return UIColor(red: 0.94, green: 0.33, blue: 0.25, alpha: 1)
        }
    }

    // MARK: - Helpers — 露出シミュレーション計算/スポット位置変換
    private var currentAperture: Aperture {
        viewModel.effectiveAperture
    }

    private var currentShutterSpeed: ShutterSpeed {
        viewModel.effectiveShutterSpeed
    }

    private var previewExposureOverlay: some View {
        ZStack {
            if underPreviewOpacity > 0 {
                Rectangle()
                    .fill(Color.black.opacity(underPreviewOpacity))
            }
            if overPreviewOpacity > 0 {
                Rectangle()
                    .fill(Color(red: 1.0, green: 0.96, blue: 0.84).opacity(overPreviewOpacity))
            }
        }
        .allowsHitTesting(false)
    }

    private var fullscreenZoomGesture: some Gesture {
        MagnificationGesture()
            .onChanged { scale in
                guard cameraManager.allowsFullscreenZoom else { return }
                if zoomGestureStartFocalLength == nil {
                    zoomGestureStartFocalLength = cameraManager.currentEquivalentFocalLength
                }
                guard let zoomGestureStartFocalLength else { return }
                cameraManager.setEquivalentFocalLength(zoomGestureStartFocalLength * Double(scale))
            }
            .onEnded { _ in
                zoomGestureStartFocalLength = nil
            }
    }

    private func adjustISO(by direction: Int, emitHaptics: Bool = true) {
        let allISOs = ISOValue.allCases
        guard let currentIndex = allISOs.firstIndex(of: viewModel.iso) else { return }
        let newIndex = max(0, min(allISOs.count - 1, currentIndex + direction))
        viewModel.iso = allISOs[newIndex]
        if emitHaptics, viewModel.enableHaptics { HapticManager.shared.selectionChanged() }
    }

    private var underPreviewOpacity: Double {
        max(0, min(0.42, -viewModel.previewAdjustmentEV * 0.15))
    }

    private var overPreviewOpacity: Double {
        max(0, min(0.34, viewModel.previewAdjustmentEV * 0.12))
    }

    private var currentLensStatusText: String {
        cameraManager.isZoomLensPreset
            ? (viewModel.showAuxiliaryLabels ? "ズーム \(cameraManager.currentLensDisplay)" : cameraManager.currentLensDisplay)
            : cameraManager.currentLensDisplay
    }

    private var usesRefinedNormalUI: Bool {
        !viewModel.showAuxiliaryLabels && !viewModel.isIncidentMode
    }

    private var incidentStatusText: String {
        viewModel.isLocked ? "HOLD" : cameraManager.measurementStateText
    }

    private var incidentStateColor: Color {
        if viewModel.isLocked {
            return usesRefinedInterface ? .cyan : .meterAccent
        }
        if cameraManager.measurementStability >= 0.82 {
            return .meterGreen
        }
        return .cyan
    }

    // MARK: - Tap Handling — タップ位置→スポット測光ポイント設定
    private func handleTap(location: CGPoint, relativeX: CGFloat, relativeY: CGFloat, previewSize: CGSize) {
        if showSpotTapGuidancePopup {
            dismissSpotTapGuidance()
        }

        if viewModel.meteringMode == .threePoint {
            guard cameraManager.threePointPendingKind != nil else { return }
            guard isInsideCenterMeteringMask(location, previewSize: previewSize) else { return }

            if viewModel.isLocked {
                viewModel.setLock(false)
                cameraManager.unlockExposure()
            }

            cameraManager.setThreePointSelectionPoint(
                CGPoint(x: 0.5, y: 0.5)
            ) { completed in
                if completed {
                    viewModel.updateMeasuredEV(cameraManager.currentEV, force: true)
                    viewModel.setLock(true, withHaptics: viewModel.enableHaptics)
                } else if viewModel.enableHaptics {
                    HapticManager.shared.lightTap()
                }
            }
            return
        }

        if viewModel.isLocked {
            viewModel.setLock(false)
            cameraManager.unlockExposure()
        }
        viewModel.meteringMode = .spot
        let sensorPoint = cameraManager.sensorPoint(
            forVisiblePreviewPoint:
            CGPoint(x: relativeX, y: relativeY),
            mirrored: viewModel.isIncidentMode
        )
        cameraManager.setSpotMeteringPoint(x: sensorPoint.x, y: sensorPoint.y)
        tapPoint = CGPoint(x: relativeX, y: relativeY)

        withAnimation(.easeOut(duration: 0.1)) { tapPointOpacity = 1.0 }
        if viewModel.enableHaptics { HapticManager.shared.lightTap() }

        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            withAnimation(.easeOut(duration: 0.5)) { tapPointOpacity = 0.3 }
        }
    }

    private func selectReflectiveMeteringMode(_ mode: MeteringMode) {
        if viewModel.isLocked {
            viewModel.setLock(false)
            cameraManager.unlockExposure()
        }
        viewModel.meteringMode = mode
        if viewModel.enableHaptics { HapticManager.shared.selectionChanged() }
        if mode == .spot {
            presentSpotTapGuidanceIfNeeded(force: true)
        }
    }

    private func handleMeteringModeSelection(_ mode: MeteringMode) {
        if viewModel.meteringMode == mode {
            if mode == .spot {
                if viewModel.enableHaptics { HapticManager.shared.selectionChanged() }
                presentSpotTapGuidanceIfNeeded(force: true)
            } else if mode == .threePoint {
                if viewModel.isLocked {
                    viewModel.setLock(false)
                    cameraManager.unlockExposure()
                }
                cameraManager.restartThreePointSelection()
                if viewModel.enableHaptics { HapticManager.shared.selectionChanged() }
            } else {
                triggerReflectiveMeasurement(withHaptics: true)
            }
        } else {
            selectReflectiveMeteringMode(mode)
        }
    }

    private func resetThreePointMetering() {
        guard viewModel.meteringMode == .threePoint else { return }
        if viewModel.isLocked {
            viewModel.setLock(false)
            cameraManager.unlockExposure()
        }
        cameraManager.restartThreePointSelection()
        if viewModel.enableHaptics { HapticManager.shared.selectionChanged() }
    }

    private func triggerReflectiveMeasurement(withHaptics: Bool) {
        guard !viewModel.isIncidentMode, !cameraManager.isReflectiveMeasurementInProgress else { return }
        viewModel.setLock(false)
        cameraManager.requestReflectiveMeasurement { ev in
            viewModel.updateMeasuredEV(ev)
            if viewModel.meteringMode == .threePoint {
                viewModel.setLock(true, withHaptics: withHaptics)
            }
        }
    }

    private var isReflectiveFullscreenVisible: Bool {
        controlPanelOffset > 0.5 && !viewModel.isIncidentMode
    }

    private func presentSpotTapGuidanceIfNeeded(force: Bool = false) {
        guard isReflectiveFullscreenVisible, viewModel.meteringMode == .spot else {
            if !viewModel.isIncidentMode {
                showSpotTapGuidancePopup = false
            }
            return
        }
        guard force || !hasShownSpotTapGuidanceForCurrentSpotSelection else { return }
        hasShownSpotTapGuidanceForCurrentSpotSelection = true
        withAnimation(.easeInOut(duration: 0.18)) {
            showSpotTapGuidancePopup = true
        }
    }

    private func dismissSpotTapGuidance() {
        withAnimation(.easeInOut(duration: 0.18)) {
            showSpotTapGuidancePopup = false
        }
    }

    private func presentSpotWarningGuide(_ warning: SpotMeteringWarning) {
        guard warning == .brightArea || warning == .offTarget else { return }
        withAnimation(.easeInOut(duration: 0.18)) {
            selectedSpotWarningGuide = warning
        }
    }

    private func dismissSpotWarningGuide() {
        withAnimation(.easeInOut(duration: 0.18)) {
            selectedSpotWarningGuide = nil
        }
    }

    private func presentThreePointMeteringGuide() {
        withAnimation(.easeInOut(duration: 0.18)) {
            showThreePointMeteringGuide = true
        }
    }

    private func dismissThreePointMeteringGuide() {
        withAnimation(.easeInOut(duration: 0.18)) {
            showThreePointMeteringGuide = false
        }
    }
}

private struct ReflectivePreviewWidthKey: PreferenceKey {
    static var defaultValue: CGFloat = 0

    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

private struct PendingShotSaveDraft: Identifiable {
    let id = UUID()
    let previewImage: CGImage
    let capturedAt: Date
    let aperture: String
    let shutterSpeed: String
    let iso: Int
    let ev: Double
    let evDifference: Double
    let exposureMode: String
    let meteringMode: String
    let exposureCompensation: Double
    let isIncident: Bool
    let zoneValue: Int
    let exposureStatus: ExposureStatus
}

private struct ShotSaveComposerSheet: View {
    @Binding var note: String
    let refined: Bool
    let isSaving: Bool
    let onCancel: () -> Void
    let onSave: () -> Void

    @FocusState private var isEditorFocused: Bool

    var body: some View {
        NavigationStack {
            ZStack {
                (refined ? Color.refinedBackground : Color.meterBackground)
                    .ignoresSafeArea()

                VStack(alignment: .leading, spacing: 14) {
                    Text("撮影時の状況や意図、フィルム名などを残せます。")
                        .font(.meterLabel(11))
                        .foregroundColor(refined ? .refinedTextSoft : .meterSecondary.opacity(0.72))

                    ZStack(alignment: .topLeading) {
                        RoundedRectangle(cornerRadius: 14)
                            .fill(refined ? Color.refinedSurface : Color.meterCardBg.opacity(0.95))
                            .overlay(
                                RoundedRectangle(cornerRadius: 14)
                                    .stroke(refined ? Color.refinedStroke : Color.black.opacity(0.12), lineWidth: 0.6)
                            )

                        if note.isEmpty {
                            Text("被写体、場所、フィルム、補足メモなど")
                                .font(.meterLabel(12))
                                .foregroundColor(refined ? .refinedTextSoft.opacity(0.7) : .meterSecondary.opacity(0.4))
                                .padding(.horizontal, 14)
                                .padding(.vertical, 16)
                                .allowsHitTesting(false)
                        }

                        TextEditor(text: $note)
                            .font(.system(size: 15, weight: .medium))
                            .foregroundColor(refined ? .refinedText : .meterSecondary)
                            .scrollContentBackground(.hidden)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 8)
                            .frame(minHeight: 156)
                            .focused($isEditorFocused)
                    }

                    HStack {
                        Text("保存画像のコラージュ枠に収まる範囲まで反映されます")
                            .font(.meterLabel(10))
                            .foregroundColor(refined ? .refinedTextSoft.opacity(0.78) : .meterSecondary.opacity(0.6))
                        Spacer()
                        Text("\(note.count)文字")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundColor(refined ? .cyan : .meterAccent)
                    }

                    Spacer(minLength: 0)
                }
                .padding(20)
            }
            .navigationTitle("撮影記録を保存")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("キャンセル") {
                        onCancel()
                    }
                    .disabled(isSaving)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(isSaving ? "保存中..." : "保存") {
                        onSave()
                    }
                    .disabled(isSaving)
                    .font(.meterValue(13))
                }
            }
            .toolbarBackground(refined ? Color.refinedSurface : Color.meterCardBg, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(refined ? .dark : .light, for: .navigationBar)
            .onAppear {
                DispatchQueue.main.async {
                    isEditorFocused = true
                }
            }
        }
        .presentationDetents([.large])
        .presentationDragIndicator(.visible)
        .preferredColorScheme(refined ? .dark : .light)
    }
}

private struct PreviewOutsideOverlayShape: Shape {
    let cutout: CGRect
    let cornerRadius: CGFloat

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.addRect(rect)
        path.addRoundedRect(
            in: cutout,
            cornerSize: CGSize(width: cornerRadius, height: cornerRadius)
        )
        return path
    }
}

private struct PreviewEllipseCutoutShape: Shape {
    let cutout: CGRect

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.addRect(rect)
        path.addEllipse(in: cutout)
        return path
    }
}

// MARK: - Metering Guide Overlay — 測光範囲のCanvas描画オーバーレイ
struct MeteringGuideOverlay: View {
    let mode: MeteringMode
    let width: CGFloat
    let height: CGFloat
    let spotPoint: CGPoint
    let spotOpacity: Double
    let threePointMetering: ThreePointMeteringDisplay?
    let threePointSelectionMarkers: [ThreePointSelectionMarker]

    var body: some View {
        ZStack {
            Canvas { context, size in
                switch mode {
                case .spot:
                    let x = width * spotPoint.x
                    let y = height * spotPoint.y
                    let color = Color.cyan.opacity(spotOpacity)
                    let outerCircle = Path(ellipseIn: CGRect(x: x - 18, y: y - 18, width: 36, height: 36))
                    context.stroke(outerCircle, with: .color(color), lineWidth: 1.5)
                    let innerCircle = Path(ellipseIn: CGRect(x: x - 8, y: y - 8, width: 16, height: 16))
                    context.stroke(innerCircle, with: .color(color.opacity(0.6)), lineWidth: 0.5)
                    var hLine = Path()
                    hLine.move(to: CGPoint(x: x - 6, y: y))
                    hLine.addLine(to: CGPoint(x: x + 6, y: y))
                    context.stroke(hLine, with: .color(color), lineWidth: 1)
                    var vLine = Path()
                    vLine.move(to: CGPoint(x: x, y: y - 6))
                    vLine.addLine(to: CGPoint(x: x, y: y + 6))
                    context.stroke(vLine, with: .color(color), lineWidth: 1)

                case .centerWeighted:
                    let centerX = width / 2
                    let centerY = height / 2
                    let color = Color.white.opacity(0.2)
                    let coreSize = width * 0.2
                    let coreCircle = Path(ellipseIn: CGRect(x: centerX - coreSize / 2, y: centerY - coreSize / 2, width: coreSize, height: coreSize))
                    context.stroke(coreCircle, with: .color(color), lineWidth: 0.5)
                    let midSize = width * 0.6
                    let midCircle = Path(ellipseIn: CGRect(x: centerX - midSize / 2, y: centerY - midSize / 2, width: midSize, height: midSize))
                    context.stroke(midCircle, with: .color(color.opacity(0.7)), lineWidth: 0.5)

                case .matrix:
                    let color = Color.white.opacity(0.15)
                    let cellWidth = width / 3
                    let cellHeight = height / 3
                    for i in 1..<3 {
                        var line = Path()
                        line.move(to: CGPoint(x: cellWidth * CGFloat(i), y: 0))
                        line.addLine(to: CGPoint(x: cellWidth * CGFloat(i), y: height))
                        context.stroke(line, with: .color(color), lineWidth: 0.5)
                    }
                    for i in 1..<3 {
                        var line = Path()
                        line.move(to: CGPoint(x: 0, y: cellHeight * CGFloat(i)))
                        line.addLine(to: CGPoint(x: width, y: cellHeight * CGFloat(i)))
                        context.stroke(line, with: .color(color), lineWidth: 0.5)
                    }
                    let centerRect = CGRect(x: cellWidth, y: cellHeight, width: cellWidth, height: cellHeight)
                    context.stroke(Path(centerRect), with: .color(Color.white.opacity(0.25)), lineWidth: 0.5)

                case .average:
                    let rect = CGRect(x: 2, y: 2, width: width - 4, height: height - 4)
                    context.stroke(Path(rect), with: .color(Color.white.opacity(0.1)), lineWidth: 0.5)

                case .threePoint:
                    break
                }
            }
        }
        .frame(width: width, height: height)
        .allowsHitTesting(false)
    }
}

// MARK: - Compact Value Control — フルスクリーン用コンパクト値調整UI
struct CompactValueControl: View {
    enum Presentation {
        case fullscreen
        case panel
    }

    let title: String
    let value: String
    var subtitle: String? = nil
    var showTitle: Bool = true
    var refined: Bool = false
    var presentation: Presentation = .panel
    var isAuto: Bool = false
    var autoTint: Color = .meterAccent
    var autoBorderLineWidth: CGFloat = 1
    let isEnabled: Bool
    let isCalculated: Bool
    let onIncrement: () -> Void
    let onDecrement: () -> Void
    @State private var swipeStepIndex: Int = 0
    @State private var isSwipeActive: Bool = false

    private let swipeStepWidth: CGFloat = 20

    private var tintColor: Color {
        if refined && !showTitle {
            if isAuto { return autoTint == .meterRed ? .meterRed : .refinedText }
            if isEnabled { return .refinedText }
            return .refinedTextSoft
        }
        if isAuto { return autoTint }
        if isEnabled { return .meterBlue }
        return .meterSecondary
    }

    private var valueFontSize: CGFloat {
        switch presentation {
        case .fullscreen:
            if refined && !showTitle {
                return title == "SS" ? 23 : 24
            }
            return title == "SS" ? 19 : 20
        case .panel:
            if refined && !showTitle {
                return title == "SS" ? 19 : 20
            }
            return title == "SS" ? 16 : 17
        }
    }

    private var valueMinimumScaleFactor: CGFloat {
        title == "SS" ? 0.58 : 0.64
    }

    var body: some View {
        VStack(spacing: 3) {
            if refined && !showTitle {
                Capsule()
                    .fill(tintColor.opacity(isAuto ? 0.92 : 0.68))
                    .frame(width: 16, height: 3)
                    .padding(.bottom, 1)
            }
            if showTitle {
                HStack(spacing: 3) {
                    Text(title)
                        .font(.meterLabel(8))
                        .tracking(1.5)
                        .foregroundColor(refined && !showTitle ? .refinedTextSoft : (isAuto ? autoTint.opacity(0.7) : isEnabled ? .meterBlue.opacity(0.7) : .meterSecondary.opacity(0.5)))
                        .textCase(.uppercase)
                }
            }
            VStack(spacing: 2) {
                VStack(spacing: 1) {
                    Text(value)
                        .font(.meterValue(valueFontSize))
                        .foregroundColor(tintColor)
                        .frame(maxWidth: .infinity)
                        .lineLimit(1)
                        .allowsTightening(true)
                        .minimumScaleFactor(valueMinimumScaleFactor)
                        .monospacedDigit()
                        .layoutPriority(1)
                    if let subtitle = subtitle ?? ((refined && !showTitle && isAuto) ? " " : nil) {
                        Text(subtitle)
                            .font(.meterValue(10))
                            .foregroundColor(self.subtitle != nil ? tintColor : .clear)
                            .lineLimit(1)
                            .minimumScaleFactor(0.6)
                            .frame(maxWidth: .infinity)
                            .frame(height: refined && !showTitle ? 10 : nil)
                    } else if !(refined && !showTitle) {
                        Text(" ")
                            .font(.meterValue(10))
                            .foregroundColor(.clear)
                            .lineLimit(1)
                            .minimumScaleFactor(0.6)
                            .frame(maxWidth: .infinity)
                    }
                }

                SwipeArrowRail(
                    tint: tintColor,
                    refined: refined && !showTitle,
                    active: isSwipeActive
                )
                .opacity(isEnabled ? 1 : 0)
            }
        }
        .frame(minHeight: refined && !showTitle ? 72 : 78)
        .padding(.vertical, 7)
        .padding(.horizontal, 6)
        .background(
            RoundedRectangle(cornerRadius: MeterShape.box)
                .fill(refined && !showTitle ? refinedBackground : defaultBackground)
                .overlay(RoundedRectangle(cornerRadius: MeterShape.box).stroke(
                    refined && !showTitle ? refinedBorder : defaultBorder,
                    lineWidth: refined && !showTitle ? (isAuto ? autoBorderLineWidth : 0.9) : (isAuto ? autoBorderLineWidth : (isEnabled ? 1 : 0.5))
                ))
        )
        .contentShape(RoundedRectangle(cornerRadius: MeterShape.box))
        .gesture(valueSwipeGesture)
        .animation(.easeInOut(duration: 0.2), value: isEnabled)
        .animation(.easeInOut(duration: 0.2), value: isAuto)
    }

    private var valueSwipeGesture: some Gesture {
        DragGesture(minimumDistance: isEnabled ? 6 : .infinity)
            .onChanged { gesture in
                guard isEnabled else { return }
                isSwipeActive = true
                let nextStep = Int(gesture.translation.width / swipeStepWidth)
                applySwipeDelta(nextStep - swipeStepIndex)
                swipeStepIndex = nextStep
            }
            .onEnded { _ in
                swipeStepIndex = 0
                isSwipeActive = false
            }
    }

    private func applySwipeDelta(_ delta: Int) {
        guard delta != 0 else { return }
        if delta > 0 {
            for _ in 0..<delta {
                onIncrement()
                HapticManager.shared.selectionChanged()
            }
        } else {
            for _ in 0..<(-delta) {
                onDecrement()
                HapticManager.shared.selectionChanged()
            }
        }
    }

    private var defaultBackground: Color {
        isAuto ? autoTint.opacity(0.08) : isEnabled ? Color.meterBlue.opacity(0.06) : Color.meterButtonBg.opacity(0.5)
    }

    private var defaultBorder: Color {
        isAuto ? autoTint : isEnabled ? Color.meterBlue.opacity(0.25) : Color.black.opacity(0.1)
    }

    private var refinedBackground: Color {
        if isAuto { return autoTint == .meterRed ? autoTint.opacity(0.16) : .refinedSurface }
        if isEnabled { return .refinedSurface }
        return .refinedBackground
    }

    private var refinedBorder: Color {
        if isAuto { return autoTint == .meterRed ? autoTint.opacity(0.95) : Color.white.opacity(0.82) }
        if isEnabled { return .refinedStroke }
        return .refinedStroke.opacity(0.36)
    }
}
