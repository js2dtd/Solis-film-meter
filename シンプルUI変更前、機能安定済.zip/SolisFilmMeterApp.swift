//
//  SolisFilmMeterApp.swift
//  Solis film meter
//

// MARK: - 役割: アプリのエントリーポイントと全体初期設定

import SwiftUI

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        return .portrait
    }
}

@main
struct SolisFilmMeterApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var sessionStore = AppSessionStore()
    
    init() {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(Color.meterBackground)
        appearance.titleTextAttributes = [.foregroundColor: UIColor(Color.meterSecondary)]
        
        UINavigationBar.appearance().standardAppearance = appearance
        UINavigationBar.appearance().scrollEdgeAppearance = appearance
        
        UISegmentedControl.appearance().selectedSegmentTintColor = UIColor(Color.meterAccent)
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor.black], for: .selected)
        UISegmentedControl.appearance().setTitleTextAttributes([.foregroundColor: UIColor(Color.meterSecondary)], for: .normal)
    }
    
    var body: some Scene {
        WindowGroup {
            MeterContainerView(sessionStore: sessionStore)
                .preferredColorScheme(.light)
        }
        .onChange(of: scenePhase) { _, newPhase in
            guard newPhase == .active else { return }
            sessionStore.incrementLaunchCountIfNeeded()
        }
    }
}
