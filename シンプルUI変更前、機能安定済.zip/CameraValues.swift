//
//  CameraValues.swift
//  Solis film meter
//

// MARK: - 役割: ISO・絞り・シャッター速度などのカメラ値定義

import Foundation
import SwiftUI

// MARK: - シャッタースピード — 1/8000〜30秒、フィルムカメラ寄りの系列、displayString/tvValue付き
enum ShutterSpeed: Double, CaseIterable, Identifiable {
    // 高速側（1/N秒）
    case s8000 = 0.000125       // 1/8000
    case s6400 = 0.00015625     // 1/6400
    case s5000 = 0.0002         // 1/5000
    case s4000 = 0.00025        // 1/4000
    case s3200 = 0.0003125      // 1/3200
    case s2500 = 0.0004         // 1/2500
    case s2000 = 0.0005         // 1/2000
    case s1600 = 0.000625       // 1/1600
    case s1250 = 0.0008         // 1/1250
    case s1000 = 0.001          // 1/1000
    case s800 = 0.00125         // 1/800
    case s640 = 0.0015625       // 1/640
    case s500 = 0.002           // 1/500
    case s400 = 0.0025          // 1/400
    case s320 = 0.003125        // 1/320
    case s250 = 0.004           // 1/250
    case s200 = 0.005           // 1/200
    case s160 = 0.00625         // 1/160
    case s125 = 0.008           // 1/125
    case s100 = 0.01            // 1/100
    case s80 = 0.0125           // 1/80
    case s60 = 0.01667          // 1/60
    case s50 = 0.02             // 1/50
    case s40 = 0.025            // 1/40
    case s30 = 0.03333          // 1/30
    case s25 = 0.04             // 1/25
    case s20 = 0.05             // 1/20
    case s15 = 0.06667          // 1/15
    case s13 = 0.07692          // 1/13
    case s10 = 0.1              // 1/10
    case s8 = 0.125             // 1/8
    case s6 = 0.16667           // 1/6
    case s5 = 0.2               // 1/5
    case s4 = 0.25              // 1/4
    case s2 = 0.5               // 1/2
    // 長秒側
    case sec1 = 1.0             // 1"
    case sec2 = 2.0             // 2"
    case sec4 = 4.0             // 4"
    case sec8 = 8.0             // 8"
    case sec15 = 15.0           // 15"
    case sec30 = 30.0           // 30"

    var id: Double { rawValue }

    var displayString: String {
        if rawValue >= 1.0 {
            if rawValue == floor(rawValue) {
                return "\(Int(rawValue))\""
            } else {
                return String(format: "%.1f\"", rawValue)
            }
        } else {
            // 1/rawValue が整数に近い場合は分数表示（1/125 等）
            // そうでない場合は秒数表示（0.3" 等）
            let denominator = 1.0 / rawValue
            let roundedDenominator = denominator.rounded()
            if abs(denominator - roundedDenominator) < 0.1 {
                return "1/\(Int(roundedDenominator))"
            } else {
                return String(format: "%.1f\"", rawValue)
            }
        }
    }

    var tvValue: Double {
        return log2(1.0 / rawValue)
    }
}

// MARK: - 絞り値 — f/0.95〜f/64（+ピンホールf/90〜f/256）、1/3段刻み
enum Aperture: Double, CaseIterable, Identifiable {
    case f0_95 = 0.95
    case f1_0 = 1.0
    case f1_1 = 1.1
    case f1_2 = 1.2
    case f1_4 = 1.4
    case f1_6 = 1.6
    case f1_8 = 1.8
    case f2_0 = 2.0
    case f2_2 = 2.2
    case f2_5 = 2.5
    case f2_8 = 2.8
    case f3_2 = 3.2
    case f3_5 = 3.5
    case f4_0 = 4.0
    case f4_5 = 4.5
    case f5_0 = 5.0
    case f5_6 = 5.6
    case f6_3 = 6.3
    case f7_1 = 7.1
    case f8_0 = 8.0
    case f9 = 9.0
    case f10 = 10.0
    case f11 = 11.0
    case f13 = 13.0
    case f14 = 14.0
    case f16 = 16.0
    case f18 = 18.0
    case f20 = 20.0
    case f22 = 22.0
    case f25 = 25.0
    case f29 = 29.0
    case f32 = 32.0
    case f36 = 36.0
    case f40 = 40.0
    case f45 = 45.0
    case f51 = 51.0
    case f57 = 57.0
    case f64 = 64.0
    // ピンホール用
    case f90 = 90.0
    case f128 = 128.0
    case f180 = 180.0
    case f256 = 256.0

    var id: Double { rawValue }

    var displayString: String {
        if rawValue == floor(rawValue) {
            return "f/\(Int(rawValue))"
        } else {
            return "f/\(rawValue)"
        }
    }

    var avValue: Double {
        return 2.0 * log2(rawValue)
    }

    static var regularValues: [Aperture] {
        allCases.filter { $0.rawValue <= 64.0 }
    }

    static var pinholeValues: [Aperture] {
        allCases.filter { $0.rawValue >= 90.0 }
    }
}

// MARK: - ISO感度 — ISO 6〜25600、svValue（感度値）付き
enum ISOValue: Int, CaseIterable, Identifiable {
    case iso6 = 6
    case iso12 = 12
    case iso25 = 25
    case iso50 = 50
    case iso100 = 100
    case iso200 = 200
    case iso400 = 400
    case iso800 = 800
    case iso1600 = 1600
    case iso3200 = 3200
    case iso6400 = 6400
    case iso12800 = 12800
    case iso25600 = 25600

    var id: Int { rawValue }

    var displayString: String { "ISO \(rawValue)" }

    var svValue: Double {
        return log2(Double(rawValue) / 100.0)
    }

    static var commonFilmValues: [ISOValue] {
        [.iso50, .iso100, .iso200, .iso400, .iso800, .iso1600, .iso3200]
    }
}

// MARK: - 測光モード — スポット/中央重点/マトリクス/平均（アイコン+表示名）
enum MeteringMode: String, CaseIterable, Identifiable {
    case spot = "spot"
    case centerWeighted = "center"
    case matrix = "matrix"
    case average = "average"
    case threePoint = "threePoint"

    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .spot: return "スポット"
        case .centerWeighted: return "中央重点"
        case .matrix: return "マルチ"
        case .average: return "平均"
        case .threePoint: return "2点"
        }
    }

    var compactLabel: String {
        switch self {
        case .spot: return "スポット"
        case .centerWeighted: return "中央"
        case .matrix: return "マルチ"
        case .average: return "平均"
        case .threePoint: return "2点"
        }
    }

    var shortDescription: String {
        switch self {
        case .spot: return "狭い範囲を測る"
        case .centerWeighted: return "中央を優先"
        case .matrix: return "全体を見て判断"
        case .average: return "全体を均等に測る"
        case .threePoint: return "中央で明暗2点を測る"
        }
    }

    var detailDescription: String {
        switch self {
        case .spot: return "小さい範囲を重点的に測ります"
        case .centerWeighted: return "中央付近を優先して測ります"
        case .matrix: return "全体を見て偏りを抑えて測ります"
        case .average: return "画面全体を均等に測ります"
        case .threePoint: return "最明部と最暗部を中央に置いて順に測ります"
        }
    }

    var icon: String {
        switch self {
        case .spot: return "circle.circle"
        case .centerWeighted: return "circle.dashed"
        case .matrix: return "rectangle.split.3x3"
        case .average: return "square.fill"
        case .threePoint: return "triangle"
        }
    }
}

enum SpotMeteringReferenceTarget: String, CaseIterable, Identifiable, Codable {
    case darkest
    case shadow
    case sunlit
    case brightest

    var id: String { rawValue }

    var title: String {
        switch self {
        case .darkest: return "最暗部"
        case .shadow: return "影部分"
        case .sunlit: return "日向部分"
        case .brightest: return "最明部"
        }
    }

    var shortTitle: String {
        switch self {
        case .darkest: return "最暗部"
        case .shadow: return "影部分"
        case .sunlit: return "日向部分"
        case .brightest: return "最明部"
        }
    }

    var iconName: String {
        switch self {
        case .darkest: return "moon.fill"
        case .shadow: return "cloud.fill"
        case .sunlit: return "sun.max.fill"
        case .brightest: return "sparkles"
        }
    }

    var detailText: String {
        switch self {
        case .darkest:
            return "画面内で最も暗い部分を基準に測光します。"
        case .shadow:
            return "影になっている部分を基準にして測光します。"
        case .sunlit:
            return "日が当たっている部分を基準にして測光します。"
        case .brightest:
            return "画面内で最も明るい部分を基準に測光します。"
        }
    }

    var warningToleranceEV: Double {
        switch self {
        case .darkest, .brightest:
            return 2.35
        case .shadow, .sunlit:
            return 2.6
        }
    }
}

enum SpotMeteringExposureBoostPreset: String, CaseIterable, Identifiable, Codable {
    case minusOne
    case minusTwoThirds
    case minusThird
    case neutral
    case plusThird
    case plusTwoThirds
    case plusOne

    var id: String { rawValue }

    var boostEV: Double {
        switch self {
        case .minusOne: return -1.0
        case .minusTwoThirds: return -(2.0 / 3.0)
        case .minusThird: return -(1.0 / 3.0)
        case .neutral: return 0
        case .plusThird: return 1.0 / 3.0
        case .plusTwoThirds: return 2.0 / 3.0
        case .plusOne: return 1.0
        }
    }

    var shortLabel: String {
        switch self {
        case .minusOne: return "-1EV"
        case .minusTwoThirds: return "-2/3EV"
        case .minusThird: return "-1/3EV"
        case .neutral: return "なし"
        case .plusThird: return "+1/3EV"
        case .plusTwoThirds: return "+2/3EV"
        case .plusOne: return "+1EV"
        }
    }

    var detailText: String {
        switch self {
        case .minusOne:
            return "かなり暗め"
        case .minusTwoThirds:
            return "標準より暗め"
        case .minusThird:
            return "少し暗め"
        case .neutral:
            return "補正なし"
        case .plusThird:
            return "少し明るめ"
        case .plusTwoThirds:
            return "標準より明るめ"
        case .plusOne:
            return "かなり明るめ"
        }
    }
}

// MARK: - 露出モード — 絞り優先(Av)/シャッター優先(Tv)/マニュアル(M)
enum ExposureMode: String, CaseIterable, Identifiable {
    case aperturePriority = "Av"
    case shutterPriority = "Tv"
    case manual = "M"

    var id: String { rawValue }
    var shortName: String { rawValue }

    var displayName: String {
        switch self {
        case .aperturePriority: return "絞り優先"
        case .shutterPriority: return "シャッター優先"
        case .manual: return "マニュアル"
        }
    }
}

// MARK: - 露出状態 — 7段階（大幅アンダー〜適正〜大幅オーバー）色+アイコン付き
enum ExposureStatus {
    case severeUnderexposure
    case underexposure
    case slightUnderexposure
    case proper
    case slightOverexposure
    case overexposure
    case severeOverexposure

    var displayName: String {
        switch self {
        case .severeUnderexposure: return "大幅アンダー"
        case .underexposure: return "アンダー"
        case .slightUnderexposure: return "やや暗い"
        case .proper: return "適正"
        case .slightOverexposure: return "やや明るい"
        case .overexposure: return "オーバー"
        case .severeOverexposure: return "大幅オーバー"
        }
    }

    var color: Color {
        switch self {
        case .severeUnderexposure: return .blue
        case .underexposure: return .cyan
        case .slightUnderexposure: return .teal
        case .proper: return .green
        case .slightOverexposure: return .yellow
        case .overexposure: return .orange
        case .severeOverexposure: return .red
        }
    }

    var icon: String {
        switch self {
        case .severeUnderexposure, .underexposure, .slightUnderexposure:
            return "minus.circle.fill"
        case .proper:
            return "checkmark.circle.fill"
        case .slightOverexposure, .overexposure, .severeOverexposure:
            return "plus.circle.fill"
        }
    }
}

// MARK: - 設定保存用 — ISO/EV表示/触覚/ピンホールのCodable構造体
struct SavedSettings: Codable {
    var defaultISO: Int
    var showEVValue: Bool
    var showAuxiliaryLabels: Bool
    var enableHaptics: Bool
    var enablePinholeMode: Bool
    var isPinholeMode: Bool
    var spotBrightAreaWarningEnabled: Bool
    var spotOffTargetWarningEnabled: Bool
    var spotMeteringReferenceTarget: SpotMeteringReferenceTarget
    var spotExposureBoostPreset: SpotMeteringExposureBoostPreset
    var hasSeenDisplayModeGuide: Bool

    private enum CodingKeys: String, CodingKey {
        case defaultISO
        case showEVValue
        case showAuxiliaryLabels
        case enableHaptics
        case enablePinholeMode
        case isPinholeMode
        case spotWarningEnabled
        case spotBrightAreaWarningEnabled
        case spotOffTargetWarningEnabled
        case spotMeteringReferenceTarget
        case spotExposureBoostPreset
        case hasSeenDisplayModeGuide
        case hasCompletedMeteringSetup
    }

    static let defaultSettings = SavedSettings(
        defaultISO: 400,
        showEVValue: true,
        showAuxiliaryLabels: true,
        enableHaptics: true,
        enablePinholeMode: false,
        isPinholeMode: false,
        spotBrightAreaWarningEnabled: true,
        spotOffTargetWarningEnabled: true,
        spotMeteringReferenceTarget: .shadow,
        spotExposureBoostPreset: .neutral,
        hasSeenDisplayModeGuide: false
    )

    init(
        defaultISO: Int,
        showEVValue: Bool,
        showAuxiliaryLabels: Bool = true,
        enableHaptics: Bool,
        enablePinholeMode: Bool = false,
        isPinholeMode: Bool = false,
        spotBrightAreaWarningEnabled: Bool = true,
        spotOffTargetWarningEnabled: Bool = true,
        spotMeteringReferenceTarget: SpotMeteringReferenceTarget = .shadow,
        spotExposureBoostPreset: SpotMeteringExposureBoostPreset = .neutral,
        hasSeenDisplayModeGuide: Bool = false
    ) {
        self.defaultISO = defaultISO
        self.showEVValue = showEVValue
        self.showAuxiliaryLabels = showAuxiliaryLabels
        self.enableHaptics = enableHaptics
        self.enablePinholeMode = enablePinholeMode
        self.isPinholeMode = isPinholeMode
        self.spotBrightAreaWarningEnabled = spotBrightAreaWarningEnabled
        self.spotOffTargetWarningEnabled = spotOffTargetWarningEnabled
        self.spotMeteringReferenceTarget = spotMeteringReferenceTarget
        self.spotExposureBoostPreset = spotExposureBoostPreset
        self.hasSeenDisplayModeGuide = hasSeenDisplayModeGuide
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        defaultISO = try container.decodeIfPresent(Int.self, forKey: .defaultISO) ?? 400
        showEVValue = try container.decodeIfPresent(Bool.self, forKey: .showEVValue) ?? true
        showAuxiliaryLabels = try container.decodeIfPresent(Bool.self, forKey: .showAuxiliaryLabels) ?? true
        enableHaptics = try container.decodeIfPresent(Bool.self, forKey: .enableHaptics) ?? true
        enablePinholeMode = try container.decodeIfPresent(Bool.self, forKey: .enablePinholeMode) ?? false
        isPinholeMode = try container.decodeIfPresent(Bool.self, forKey: .isPinholeMode) ?? false
        let legacyWarningEnabled = try container.decodeIfPresent(Bool.self, forKey: .spotWarningEnabled) ?? true
        spotBrightAreaWarningEnabled = try container.decodeIfPresent(Bool.self, forKey: .spotBrightAreaWarningEnabled) ?? legacyWarningEnabled
        spotOffTargetWarningEnabled = try container.decodeIfPresent(Bool.self, forKey: .spotOffTargetWarningEnabled) ?? legacyWarningEnabled
        spotMeteringReferenceTarget = try container.decodeIfPresent(SpotMeteringReferenceTarget.self, forKey: .spotMeteringReferenceTarget) ?? .shadow
        spotExposureBoostPreset = try container.decodeIfPresent(SpotMeteringExposureBoostPreset.self, forKey: .spotExposureBoostPreset) ?? .neutral
        hasSeenDisplayModeGuide =
            try container.decodeIfPresent(Bool.self, forKey: .hasSeenDisplayModeGuide)
            ?? (try container.decodeIfPresent(Bool.self, forKey: .hasCompletedMeteringSetup) ?? false)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(defaultISO, forKey: .defaultISO)
        try container.encode(showEVValue, forKey: .showEVValue)
        try container.encode(showAuxiliaryLabels, forKey: .showAuxiliaryLabels)
        try container.encode(enableHaptics, forKey: .enableHaptics)
        try container.encode(enablePinholeMode, forKey: .enablePinholeMode)
        try container.encode(isPinholeMode, forKey: .isPinholeMode)
        try container.encode(spotBrightAreaWarningEnabled, forKey: .spotBrightAreaWarningEnabled)
        try container.encode(spotOffTargetWarningEnabled, forKey: .spotOffTargetWarningEnabled)
        try container.encode(spotMeteringReferenceTarget, forKey: .spotMeteringReferenceTarget)
        try container.encode(spotExposureBoostPreset, forKey: .spotExposureBoostPreset)
        try container.encode(hasSeenDisplayModeGuide, forKey: .hasSeenDisplayModeGuide)
    }
}
